

import React, { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { Enrollment } from "@/api/entities";
import { getUserRole } from "./components/utils/getUserRole";
import NotificationBell from "./components/layout/NotificationBell";
import {
  BookOpen,
  Users,
  Phone,
  Menu,
  X,
  GraduationCap,
  Home,
  PlayCircle,
  FileText,
  BarChart3,
  UserCircle,
  LogOut,
  Clock,
  Calendar as CalendarIcon,
  MessageSquare,
  Folder,
  MessageCircle,
  Award
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [hasEnrollments, setHasEnrollments] = useState(false);
  
  // School info modal state
  const [showSchoolModal, setShowSchoolModal] = useState(false);
  const [schoolData, setSchoolData] = useState({
    school_graduated: "",
    has_att_permit: false
  });
  const [schoolError, setSchoolError] = useState("");

  useEffect(() => {
    loadUser();
    
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    
    return () => clearInterval(timer);
  }, []);

  const loadUser = async () => {
    try {
      const user = await base44.auth.me();
      console.log("Logged in user:", user);
      setCurrentUser(user);
      
      // Check if user needs to fill school info, only for logged-in users
      if (user && !user.school_graduated) {
        setShowSchoolModal(true);
        setSchoolData({
          school_graduated: user.school_graduated || "",
          has_att_permit: user.has_att_permit || false
        });
        setLoading(false); // Stop loading spinner, show modal instead
        return; // Exit early, don't proceed with other user-specific loading
      }
      
      if (getUserRole(user) === 'student') {
        const enrollments = await Enrollment.filter({ student_id: user.id });
        setHasEnrollments(enrollments.length > 0);
      } else {
        setHasEnrollments(true);
      }
    } catch (error) {
      console.log("No user logged in", error);
      setCurrentUser(null);
      setHasEnrollments(false);
    }
    setLoading(false); // Ensure loading is false after attempt
  };

  const handleSaveSchoolInfo = async () => {
    if (!schoolData.school_graduated.trim()) {
      setSchoolError("Please enter your school/university");
      return;
    }

    setSchoolError(""); // Clear any previous errors
    try {
      await base44.auth.updateMe({
        school_graduated: schoolData.school_graduated,
        has_att_permit: schoolData.has_att_permit,
        att_permit_date: schoolData.has_att_permit ? new Date().toISOString().split('T')[0] : null
      });
      
      // Reload the user data after successful update
      window.location.reload(); 
    } catch (error) {
      console.error("Error saving school info:", error);
      setSchoolError("Failed to save information. Please try again.");
    }
  };

  const handleLogout = async () => {
    await base44.auth.logout(createPageUrl("LandingPage"));
  };

  const handleLoginClick = (e) => {
    e.preventDefault();
    e.stopPropagation();
    base44.auth.redirectToLogin(window.location.href);
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short',
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getNavigationItems = () => {
    const userRole = getUserRole(currentUser);
    
    // Restrict navigation if user is not logged in, or if a student has no enrollments
    if (!currentUser || !userRole || (userRole === 'student' && !hasEnrollments)) {
      return [
        { name: "Home", url: createPageUrl("LandingPage"), icon: Home },
        { name: "About Us", url: createPageUrl("About"), icon: Users },
        { name: "Courses Offered", url: createPageUrl("Programs"), icon: BookOpen },
        { name: "Our Lecturers", url: createPageUrl("Instructors"), icon: Users },
        { name: "Testimonials", url: createPageUrl("Testimonials"), icon: MessageCircle },
        { name: "Contact", url: createPageUrl("Contact"), icon: Phone },
      ];
    }

    switch (userRole) {
      case 'admin':
        return [
          { name: "Home", url: createPageUrl("LandingPage"), icon: Home },
          { name: "Dashboard", url: createPageUrl("AdminDashboard"), icon: BarChart3 },
          { name: "Courses", url: createPageUrl("AdminCourses"), icon: BookOpen },
          { name: "Modules", url: createPageUrl("AdminModules"), icon: Folder },
          { name: "Videos", url: createPageUrl("AdminVideos"), icon: PlayCircle },
          { name: "Quizzes", url: createPageUrl("AdminQuizzes"), icon: FileText },
          { name: "Materials", url: createPageUrl("AdminMaterials"), icon: FileText },
          { name: "Users", url: createPageUrl("AdminUsers"), icon: Users },
          { name: "Performance", url: createPageUrl("StudentPerformance"), icon: BarChart3 },
          { name: "Calendar", url: createPageUrl("Calendar"), icon: CalendarIcon },
          { name: "Messages", url: createPageUrl("Messages"), icon: MessageSquare },
        ];
      case 'teacher':
        return [
          { name: "Home", url: createPageUrl("LandingPage"), icon: Home },
          { name: "Dashboard", url: createPageUrl("TeacherDashboard"), icon: Home },
          { name: "My Courses", url: createPageUrl("TeacherCourses"), icon: BookOpen },
          { name: "Performance", url: createPageUrl("StudentPerformance"), icon: BarChart3 },
          { name: "Calendar", url: createPageUrl("Calendar"), icon: CalendarIcon },
          { name: "Messages", url: createPageUrl("Messages"), icon: MessageSquare },
        ];
      default: // Student
        return [
          { name: "Home", url: createPageUrl("LandingPage"), icon: Home },
          { name: "Dashboard", url: createPageUrl("StudentDashboard"), icon: Home },
          { name: "My Courses", url: createPageUrl("StudentCourses"), icon: BookOpen },
          { name: "Progress", url: createPageUrl("StudentProgress"), icon: BarChart3 },
          { name: "Calendar", url: createPageUrl("Calendar"), icon: CalendarIcon },
          { name: "Messages", url: createPageUrl("Messages"), icon: MessageSquare },
        ];
    }
  };

  const isActiveRoute = (url) => location.pathname === url;

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-navy-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* School Info Required Modal */}
      <Dialog open={showSchoolModal} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-[500px]" onInteractOutside={(e) => e.preventDefault()}>
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold text-center">Complete Your Profile</DialogTitle>
            <p className="text-sm text-gray-600 text-center mt-2">
              Please provide the following information to continue
            </p>
          </DialogHeader>

          <div className="space-y-4 mt-6">
            {schoolError && (
              <div className="bg-red-50 text-red-600 p-3 rounded-lg text-sm">
                {schoolError}
              </div>
            )}

            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="school" className="text-base font-semibold">
                  School/University Graduated *
                </Label>
                <div className="relative">
                  <GraduationCap className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    id="school"
                    type="text"
                    placeholder="e.g., University of California"
                    value={schoolData.school_graduated}
                    onChange={(e) => setSchoolData({...schoolData, school_graduated: e.target.value})}
                    className="pl-10 text-base"
                    required
                    autoFocus
                  />
                </div>
                <p className="text-xs text-gray-500">
                  Enter the name of the school or university where you graduated
                </p>
              </div>

              <div className="flex items-start space-x-3 p-4 bg-navy-50 rounded-lg border border-navy-200">
                <Checkbox
                  id="att-permit-modal"
                  checked={schoolData.has_att_permit}
                  onCheckedChange={(checked) => setSchoolData({...schoolData, has_att_permit: checked})}
                  className="mt-1"
                />
                <div className="flex-1">
                  <label
                    htmlFor="att-permit-modal"
                    className="text-sm font-medium leading-none cursor-pointer flex items-center"
                  >
                    <Award className="w-4 h-4 mr-2 text-navy-600" />
                    I have authorization to take the ATT (Authorization to Test)
                  </label>
                  <p className="text-xs text-gray-500 mt-2">
                    Check this if you already have your Authorization to Test permit for NCLEX
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mt-4">
              <p className="text-sm text-yellow-800">
                <strong>Note:</strong> This information is required to access the platform. You can update it later in your profile settings.
              </p>
            </div>

            <Button 
              onClick={handleSaveSchoolInfo}
              className="w-full bg-navy-600 hover:bg-navy-700 text-lg py-6 mt-6"
              size="lg"
            >
              Save & Continue
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-gray-200 shadow-sm">
        <div className="w-full px-6 lg:px-12">
          <div className="flex justify-between items-center h-20">
            <Link to={createPageUrl("LandingPage")} className="flex items-center space-x-3">
              <div className="w-12 h-12 bg-gradient-to-br from-navy-700 to-navy-900 rounded-xl flex items-center justify-center shadow-lg">
                <GraduationCap className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-slate-800">One Quest</h1>
              </div>
            </Link>

            <nav className="hidden md:flex items-center space-x-2">
              {getNavigationItems().map((item) => (
                <Link
                  key={item.name}
                  to={item.url}
                  className={`px-4 py-2.5 rounded-lg text-base font-medium transition-all duration-200 border-b-2 ${
                    isActiveRoute(item.url)
                      ? 'bg-navy-600 text-white border-navy-700 shadow-md'
                      : 'text-gray-600 hover:text-navy-700 hover:bg-navy-50 border-transparent'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>

            <div className="flex items-center space-x-4">
              {currentUser && (
                <>
                  <div className="hidden lg:flex items-center space-x-2 text-sm text-gray-600 bg-gray-50 px-4 py-2.5 rounded-lg">
                    <Clock className="w-5 h-5" />
                    <div className="text-right">
                      <div className="font-medium text-base">{formatTime(currentTime)}</div>
                      <div className="text-xs text-gray-500">{formatDate(currentTime)}</div>
                    </div>
                  </div>
                  <NotificationBell currentUser={currentUser} />
                </>
              )}
              
              {currentUser ? (
                <div className="flex items-center space-x-3">
                  <div className="hidden md:block text-right">
                    <p className="text-base font-medium text-gray-900">{currentUser.full_name || currentUser.email}</p>
                    <p className="text-sm text-gray-500">{currentUser.email}</p>
                    <p className="text-xs text-gray-400 capitalize">{getUserRole(currentUser)}</p>
                  </div>
                  <Link to={createPageUrl("StudentProfile")}>
                    <div className="w-10 h-10 bg-navy-100 rounded-full flex items-center justify-center cursor-pointer hover:bg-navy-200 transition-colors">
                      <span className="text-base font-medium text-navy-600">
                        {(currentUser.full_name || currentUser.email)?.[0]?.toUpperCase() || 'U'}
                      </span>
                    </div>
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="hidden md:block p-2.5 text-gray-400 hover:text-gray-600 transition-colors"
                    title="Logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleLoginClick}
                  className="px-8 py-3 bg-gradient-to-r from-navy-600 to-navy-800 text-white rounded-lg font-medium hover:from-navy-700 hover:to-navy-900 transition-all duration-200 shadow-md text-base"
                >
                  Log In
                </button>
              )}

              <button
                className="md:hidden p-2.5 rounded-lg text-gray-600 hover:bg-gray-100"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              >
                {mobileMenuOpen ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-gray-100 shadow-lg">
            <div className="px-4 py-4 space-y-2">
              {currentUser && (
                <div className="pb-4 mb-4 border-b border-gray-200">
                  <p className="font-semibold text-gray-900">{currentUser.full_name || currentUser.email}</p>
                  <p className="text-sm text-gray-600">{currentUser.email}</p>
                  <p className="text-xs text-gray-500 capitalize mt-1">{getUserRole(currentUser)}</p>
                </div>
              )}
              
              {getNavigationItems().map((item) => (
                <Link
                  key={item.name}
                  to={item.url}
                  className={`flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-all duration-200 ${
                    isActiveRoute(item.url)
                      ? 'bg-navy-600 text-white shadow-md'
                      : 'text-gray-600 hover:bg-navy-50 hover:text-navy-700'
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <item.icon className="w-5 h-5" />
                  {item.name}
                </Link>
              ))}
              {!currentUser && (
                <button
                  onClick={(e) => {
                    setMobileMenuOpen(false);
                    handleLoginClick(e);
                  }}
                  className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium text-navy-600 hover:bg-navy-50 w-full text-left"
                >
                  <UserCircle className="w-5 h-5" />
                  Log In
                </button>
              )}
              {currentUser && (
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium text-red-600 hover:bg-red-50 w-full text-left"
                >
                  <LogOut className="w-5 h-5" />
                  Logout
                </button>
              )}
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">
        {children}
      </main>
    </div>
  );
}

