
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Clock, Users, CheckCircle, Star, Award } from "lucide-react";
import ProgramCard from "../components/programs/ProgramCard";
import ProgramComparison from "../components/programs/ProgramComparison";

const programs = [
  {
    id: 1,
    title: "NCLEX-RN Review Course",
    subtitle: "Complete Preparation for Registered Nurses",
    description: "Our flagship program designed for RN candidates. Comprehensive content review, thousands of practice questions, and personalized study plans to ensure your success.",
    duration: "8 weeks",
    format: "Live Online + Self-Paced",
    students: "2,500+ enrolled",
    price: 599,
    features: [
      "72 hours of live instruction",
      "10,000+ practice questions", 
      "Personalized study plan",
      "Expert NCLEX instructors",
      "Small group sessions (max 20 students)",
      "Unlimited practice tests",
      "Study materials included",
      "24/7 online support",
      "Money-back guarantee"
    ],
    highlights: [
      "98% first-time pass rate",
      "Average score improvement: 85%",
      "Comprehensive content review",
      "Test-taking strategies included"
    ],
    popular: true,
    gradient: "from-blue-500 to-blue-600",
    passRate: "98%"
  },
  {
    id: 2,
    title: "NCLEX-PN Review Course",
    subtitle: "Focused Preparation for Practical Nurses", 
    description: "Specifically designed for LPN/LVN candidates with targeted content review and practice questions aligned with the NCLEX-PN test plan.",
    duration: "6 weeks",
    format: "Live Online + Self-Paced",
    students: "1,200+ enrolled",
    price: 399,
    features: [
      "48 hours of live instruction",
      "5,000+ practice questions",
      "Content review sessions", 
      "Experienced LPN instructors",
      "Small class sizes (max 15 students)",
      "Weekly practice exams",
      "Digital study guides",
      "Email support included",
      "Satisfaction guarantee"
    ],
    highlights: [
      "95% first-time pass rate",
      "Focused PN content",
      "Practical test strategies",
      "Proven methodology"
    ],
    popular: false,
    gradient: "from-teal-500 to-teal-600", 
    passRate: "95%"
  },
  {
    id: 3,
    title: "NCLEX Intensive Bootcamp",
    subtitle: "Fast-Track Preparation in 2 Weeks",
    description: "Accelerated program for students who need to prepare quickly. Intensive daily sessions covering all essential topics with rapid skill building.",
    duration: "2 weeks",
    format: "Live Online Intensive",
    students: "800+ enrolled", 
    price: 299,
    features: [
      "40 hours intensive instruction",
      "3,000+ targeted practice questions",
      "Daily 4-hour sessions",
      "Rapid content review",
      "Priority instructor access",
      "Daily mock examinations", 
      "Essential study materials",
      "Fast-track support",
      "Performance guarantee"
    ],
    highlights: [
      "92% pass rate",
      "Rapid skill building", 
      "Intensive format",
      "Quick preparation"
    ],
    popular: false,
    gradient: "from-purple-500 to-purple-600",
    passRate: "92%"
  }
];

export default function Programs() {
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    // Try to get current user but don't redirect if not logged in
    const checkUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        // User not logged in - this is fine for public pages
        setCurrentUser(null);
      }
    };
    checkUser();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 pt-20">
      {/* Hero Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
              NCLEX Review Programs
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Choose from our expertly designed programs, each tailored to different learning styles and preparation timelines. All programs come with our success guarantee.
            </p>
          </div>

          {/* Programs Grid */}
          <div className="space-y-8">
            {programs.map((program) => (
              <ProgramCard key={program.id} program={program} />
            ))}
          </div>
        </div>
      </section>

      {/* Comparison Section */}
      <ProgramComparison programs={programs} />

      {/* Success Stats */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">
              Our Programs Deliver Results
            </h2>
            <p className="text-gray-600">
              Proven success rates across all our NCLEX preparation programs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-4xl font-bold text-blue-600 mb-2">98%</div>
              <div className="text-gray-600">Average Success Rate</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-green-600 mb-2">5,500+</div>
              <div className="text-gray-600">Students Enrolled</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-purple-600 mb-2">85%</div>
              <div className="text-gray-600">Score Improvement</div>
            </div>
            <div className="text-center">
              <div className="text-4xl font-bold text-orange-600 mb-2">24/7</div>
              <div className="text-gray-600">Student Support</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
