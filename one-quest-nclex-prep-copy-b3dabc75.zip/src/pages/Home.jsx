import React, { useEffect, useState } from "react";
import { createPageUrl } from "@/utils";
import { base44 } from "@/api/base44Client";
import { getUserRole } from "../components/utils/getUserRole";

export default function Home() {
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const checkAndRedirect = async () => {
      try {
        // Check if user is authenticated
        const isAuth = await base44.auth.isAuthenticated();
        
        if (isAuth) {
          // Get user data
          const user = await base44.auth.me();
          console.log("Authenticated user:", user);
          
          // Redirect based on user role/type
          const userRole = getUserRole(user);
          
          if (userRole === 'admin') {
            window.location.href = createPageUrl("AdminDashboard");
          } else if (userRole === 'teacher') {
            window.location.href = createPageUrl("TeacherDashboard");
          } else {
            // For students or users without user_type, go to StudentDashboard
            window.location.href = createPageUrl("StudentDashboard");
          }
        } else {
          // Not authenticated, go to landing page
          window.location.href = createPageUrl("LandingPage");
        }
      } catch (error) {
        console.log("Authentication check error:", error);
        // On error, redirect to landing page
        window.location.href = createPageUrl("LandingPage");
      }
    };

    checkAndRedirect();
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
        <p className="text-gray-600">Loading...</p>
      </div>
    </div>
  );
}