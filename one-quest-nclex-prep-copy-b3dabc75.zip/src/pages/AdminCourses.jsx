
import React, { useState, useEffect } from 'react';
import { Course } from '@/api/entities';
import { User } from '@/api/entities';
import { Video } from '@/api/entities';
import { Enrollment } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from '@/components/ui/label';
import { PlusCircle, Edit, Trash2, BookOpen, Users, Clock, Play, MoreVertical, AlertCircle, Folder, ChevronDown, ChevronRight } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Link } from 'react-router-dom';
import { getUserRole } from '../components/utils/getUserRole';
import { createPageUrl } from '@/utils';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import LoadingScreen from '../components/shared/LoadingScreen';
import { Checkbox } from '@/components/ui/checkbox'; // Added import for Checkbox

const CourseForm = ({ course, setCourse, teachers }) => {
  const [uploadingCover, setUploadingCover] = useState(false);
  const [uploadError, setUploadError] = useState(null);
  const [retryCount, setRetryCount] = useState(0);
  const maxRetries = 2;

  const handleCoverUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const MAX_FILE_SIZE = 5 * 1024 * 1024;
    if (file.size > MAX_FILE_SIZE) {
      setUploadError("File size must be less than 5MB");
      return;
    }

    if (!file.type.startsWith('image/')) {
      setUploadError("Please upload an image file");
      return;
    }

    setUploadingCover(true);
    setUploadError(null);

    let attempt = 0;

    while (attempt <= maxRetries) {
      try {
        const { UploadFile } = await import('@/api/integrations');
        const result = await UploadFile({ file });
        setCourse({ ...course, cover_photo_url: result.file_url });
        setUploadingCover(false);
        setUploadError(null);
        setRetryCount(0);
        return;
      } catch (error) {
        attempt++;
        console.error(`Upload attempt ${attempt} failed:`, error);
        
        if (attempt > maxRetries) {
          setUploadingCover(false);
          
          if (error.message?.includes('timeout') || error.message?.includes('DatabaseTimeout')) {
            setUploadError("Upload timed out. Please try again or use a smaller image.");
          } else if (error.response?.status === 500) {
            setUploadError("Server error occurred. Please try again in a moment.");
          } else {
            setUploadError("Failed to upload image. Please try again.");
          }
          setRetryCount(0);
        } else {
          await new Promise(resolve => setTimeout(resolve, 1000 * attempt));
          setRetryCount(attempt);
        }
      }
    }
  };

  const clearCoverPhoto = () => {
    setCourse({ ...course, cover_photo_url: null });
    setUploadError(null);
  };

  return (
    <div className="space-y-4">
      <Input
        placeholder="Course Title"
        value={course.title || ''}
        onChange={(e) => setCourse({ ...course, title: e.target.value })}
      />
      <Textarea
        placeholder="Description"
        value={course.description || ''}
        onChange={(e) => setCourse({ ...course, description: e.target.value })}
        className="text-justify"
      />

      <div className="space-y-2">
        <Label htmlFor="cover-photo">Course Cover Photo</Label>
        
        {uploadError && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{uploadError}</AlertDescription>
          </Alert>
        )}
        
        <Input
          id="cover-photo"
          type="file"
          accept="image/*"
          onChange={handleCoverUpload}
          disabled={uploadingCover}
        />
        
        {uploadingCover && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
            <span>Uploading{retryCount > 0 ? ` (retry ${retryCount}/${maxRetries})` : ''}...</span>
          </div>
        )}
        
        {course.cover_photo_url && (
          <div className="mt-2 relative">
            <img
              src={course.cover_photo_url}
              alt="Course cover"
              className="w-full h-40 object-cover rounded-lg"
            />
            <Button
              type="button"
              variant="destructive"
              size="sm"
              onClick={clearCoverPhoto}
              className="absolute top-2 right-2 px-3 py-1 text-xs"
            >
              Remove
            </Button>
          </div>
        )}
        
        <p className="text-xs text-gray-500">
          Recommended: 800x400px, max 5MB. Supported formats: JPG, PNG, GIF.
        </p>
      </div>

      <Select
        value={course.category || ''}
        onValueChange={(value) => setCourse({ ...course, category: value })}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Category" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="nclex-rn">NCLEX-RN</SelectItem>
          <SelectItem value="nclex-pn">NCLEX-PN</SelectItem>
          <SelectItem value="fundamentals">Fundamentals</SelectItem>
          <SelectItem value="pharmacology">Pharmacology</SelectItem>
          <SelectItem value="pathophysiology">Pathophysiology</SelectItem>
        </SelectContent>
      </Select>

      <Select
        value={course.phase || ''}
        onValueChange={(value) => setCourse({ ...course, phase: value })}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Phase *" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="phase1">Phase 1</SelectItem>
          <SelectItem value="phase2">Phase 2</SelectItem>
          <SelectItem value="phase3">Phase 3</SelectItem>
        </SelectContent>
      </Select>

      <Select
        value={course.difficulty_level || 'BEGINNER'}
        onValueChange={(value) => setCourse({ ...course, difficulty_level: value })}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Difficulty Level" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="BEGINNER">Beginner</SelectItem>
          <SelectItem value="INTERMEDIATE">Intermediate</SelectItem>
          <SelectItem value="ADVANCED">Advanced</SelectItem>
        </SelectContent>
      </Select>

      <Select
        value={course.instructor_id || ''}
        onValueChange={(value) => setCourse({ ...course, instructor_id: value })}
      >
        <SelectTrigger>
          <SelectValue placeholder="Select Instructor" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value={null}>No Instructor Assigned</SelectItem>
          {teachers.map(teacher => (
            <SelectItem key={teacher.id} value={teacher.id}>
              {teacher.full_name}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Input
        type="number"
        placeholder="Duration (weeks)"
        value={course.duration_weeks || ''}
        onChange={(e) => setCourse({ ...course, duration_weeks: Number(e.target.value) })}
      />
      <Input
        type="number"
        placeholder="Order Index"
        value={course.order_index || ''}
        onChange={(e) => setCourse({ ...course, order_index: Number(e.target.value) })}
      />
    </div>
  );
};

export default function AdminCourses() {
  const [courses, setCourses] = useState([]);
  const [teachers, setTeachers] = useState([]);
  const [courseStats, setCourseStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [accessDenied, setAccessDenied] = useState(false);
  const [expandedPhases, setExpandedPhases] = useState(new Set(['phase1', 'phase2', 'phase3']));
  const [isAssignStudentModalOpen, setIsAssignStudentModalOpen] = useState(false);
  const [selectedPhase, setSelectedPhase] = useState(null);
  const [allStudents, setAllStudents] = useState([]);
  const [selectedStudentIds, setSelectedStudentIds] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);

      const userRole = getUserRole(user);

      if (userRole !== 'admin') {
        setAccessDenied(true);
        setLoading(false);
        return;
      }

      const [allCourses, allUsers, allVideos, allEnrollments] = await Promise.all([
        Course.list('order_index'),
        User.list(),
        Video.list(),
        Enrollment.list()
      ]);

      setCourses(allCourses);

      const teacherUsers = allUsers.filter(u => getUserRole(u) === 'teacher');
      setTeachers(teacherUsers);

      const studentUsers = allUsers.filter(u => getUserRole(u) === 'student');
      setAllStudents(studentUsers);

      const stats = {};
      allCourses.forEach(course => {
        const videoCount = allVideos.filter(v => v.course_id === course.id).length;
        const enrollmentCount = allEnrollments.filter(e => e.course_id === course.id).length;
        stats[course.id] = { videos: videoCount, students: enrollmentCount };
      });
      setCourseStats(stats);

    } catch (error) {
      console.error("Error loading data:", error);
      setAccessDenied(true);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!editingCourse || !editingCourse.title) {
      alert("Please provide a course title");
      return;
    }

    if (!editingCourse.phase) {
      alert("Please select a phase for the course");
      return;
    }

    try {
      const courseData = {
        ...editingCourse,
        order_index: editingCourse.order_index || 0,
        difficulty_level: editingCourse.difficulty_level || 'BEGINNER',
        cover_photo_url: editingCourse.cover_photo_url || null
      };

      if (editingCourse.id) {
        await Course.update(editingCourse.id, courseData);
      } else {
        await Course.create(courseData);
      }
      await loadData();
      setIsModalOpen(false);
      setEditingCourse(null);
    } catch (error) {
      console.error("Error saving course:", error);
      alert("Failed to save course. Please try again.");
    }
  };

  const handleDelete = async () => {
    if (!editingCourse) return;
    try {
      await Course.delete(editingCourse.id);
      await loadData();
      setIsDeleteModalOpen(false);
      setEditingCourse(null);
    } catch (error) {
      console.error("Error deleting course:", error);
    }
  };

  const openAddModal = () => {
    setEditingCourse({ phase: 'phase1' });
    setIsModalOpen(true);
  };

  const openEditModal = (course) => {
    setEditingCourse(course);
    setIsModalOpen(true);
  };

  const openDeleteModal = (course) => {
    setEditingCourse(course);
    setIsDeleteModalOpen(true);
  };

  const getTeacherInfo = (teacherId) => {
    if (!teacherId) return null;
    return teachers.find(t => t.id === teacherId);
  };

  const getDifficultyLevel = (course) => {
    return course.difficulty_level || 'BEGINNER';
  };

  const getDifficultyColor = (level) => {
    const colors = {
      'BEGINNER': 'bg-green-500',
      'INTERMEDIATE': 'bg-yellow-500',
      'ADVANCED': 'bg-red-500'
    };
    return colors[level] || 'bg-green-500';
  };

  const togglePhase = (phase) => {
    setExpandedPhases(prev => {
      const newSet = new Set(prev);
      if (newSet.has(phase)) {
        newSet.delete(phase);
      } else {
        newSet.add(phase);
      }
      return newSet;
    });
  };

  const openAssignStudentModal = (phase) => {
    setSelectedPhase(phase);
    setSelectedStudentIds([]);
    setIsAssignStudentModalOpen(true);
  };

  const handleAssignStudents = async () => {
    if (selectedStudentIds.length === 0) {
      alert("Please select at least one student");
      return;
    }

    try {
      // Update each selected student's phase
      await Promise.all(
        selectedStudentIds.map(studentId => 
          User.update(studentId, { assigned_phase: selectedPhase })
        )
      );

      alert(`Successfully assigned ${selectedStudentIds.length} student(s) to ${selectedPhase.replace('phase', 'Phase ')}`);
      setIsAssignStudentModalOpen(false);
      setSelectedStudentIds([]);
      await loadData();
    } catch (error) {
      console.error("Error assigning students to phase:", error);
      alert("Failed to assign students. Please try again.");
    }
  };

  const toggleStudentSelection = (studentId) => {
    setSelectedStudentIds(prev => {
      if (prev.includes(studentId)) {
        return prev.filter(id => id !== studentId);
      } else {
        return [...prev, studentId];
      }
    });
  };

  const coursesByPhase = {
    phase1: courses.filter(c => c.phase === 'phase1'),
    phase2: courses.filter(c => c.phase === 'phase2'),
    phase3: courses.filter(c => c.phase === 'phase3'),
    unassigned: courses.filter(c => !c.phase)
  };

  const phaseInfo = {
    phase1: { name: 'Phase 1', color: 'from-blue-500 to-blue-600', icon: '1️⃣' },
    phase2: { name: 'Phase 2', color: 'from-purple-500 to-purple-600', icon: '2️⃣' },
    phase3: { name: 'Phase 3', color: 'from-teal-500 to-teal-600', icon: '3️⃣' },
    unassigned: { name: 'Unassigned', color: 'from-gray-400 to-gray-500', icon: '📋' }
  };

  if (loading) {
    return <LoadingScreen message="Loading courses..." />;
  }

  if (accessDenied) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h2>
          <p className="text-gray-600 mb-6">
            You don't have permission to access this page.
          </p>
          <Link to={createPageUrl("Home")}>
            <Button>Go to Home</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-blue-50 to-indigo-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-teal-600 bg-clip-text text-transparent">Course Catalog</h1>
            <p className="text-gray-600 mt-2 text-lg">Organize and manage courses by learning phases</p>
          </div>
          <Button onClick={openAddModal} className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white shadow-lg">
            <PlusCircle className="w-5 h-5 mr-2" /> Add New Course
          </Button>
        </div>

        {courses.length > 0 ? (
          <div className="space-y-6">
            {Object.entries(coursesByPhase).map(([phase, phaseCourses]) => {
              if (phaseCourses.length === 0 && phase !== 'unassigned') return null;
              
              const info = phaseInfo[phase];
              const isExpanded = expandedPhases.has(phase);

              return (
                <div key={phase} className="bg-white rounded-2xl shadow-xl border-2 border-gray-100 overflow-hidden">
                  <button
                    onClick={() => togglePhase(phase)}
                    className={`w-full p-6 bg-gradient-to-r ${info.color} text-white hover:opacity-90 transition-opacity`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <span className="text-3xl">{info.icon}</span>
                        <div className="text-left">
                          <h2 className="text-2xl font-bold">{info.name}</h2>
                          <p className="text-white/90 text-sm">{phaseCourses.length} course{phaseCourses.length !== 1 ? 's' : ''}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {phase !== 'unassigned' && (
                          <Button
                            onClick={(e) => {
                              e.stopPropagation();
                              openAssignStudentModal(phase);
                            }}
                            className="bg-white/20 hover:bg-white/30 text-white border-2 border-white/50"
                          >
                            <Users className="w-4 h-4 mr-2" />
                            Assign Students
                          </Button>
                        )}
                        {isExpanded ? (
                          <ChevronDown className="w-8 h-8" />
                        ) : (
                          <ChevronRight className="w-8 h-8" />
                        )}
                      </div>
                    </div>
                  </button>

                  {isExpanded && (
                    <div className="p-6">
                      {phaseCourses.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                          {phaseCourses.map((course) => {
                            const teacher = getTeacherInfo(course.instructor_id);
                            const stats = courseStats[course.id] || { videos: 0, students: 0 };
                            const difficultyLevel = getDifficultyLevel(course);
                            const difficultyColor = getDifficultyColor(difficultyLevel);

                            return (
                              <div key={course.id} className="bg-white rounded-xl shadow-md border-2 border-gray-100 overflow-hidden hover:shadow-2xl hover:border-blue-300 transition-all duration-300">
                                <div className="relative h-48">
                                  {course.cover_photo_url ? (
                                    <img
                                      src={course.cover_photo_url}
                                      alt={`${course.title} cover`}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <div className="w-full h-full bg-gradient-to-br from-blue-500 to-teal-500 flex items-center justify-center">
                                      <BookOpen className="w-20 h-20 text-white/30" />
                                    </div>
                                  )}

                                  <div className="absolute top-3 left-3">
                                    <span className={`${difficultyColor} text-white text-xs font-bold px-3 py-1 rounded-full uppercase`}>
                                      {difficultyLevel}
                                    </span>
                                  </div>
                                  <div className="absolute top-3 right-3">
                                    <DropdownMenu>
                                      <DropdownMenuTrigger asChild>
                                        <button className="bg-white/90 backdrop-blur-sm p-2 rounded-full hover:bg-white transition-colors">
                                          <MoreVertical className="w-4 h-4 text-gray-700" />
                                        </button>
                                      </DropdownMenuTrigger>
                                      <DropdownMenuContent align="end">
                                        <DropdownMenuItem>
                                          <Link to={createPageUrl(`AdminCourseDetail?id=${course.id}`)} className="flex items-center w-full">
                                            <BookOpen className="w-4 h-4 mr-2" /> Open Course
                                          </Link>
                                        </DropdownMenuItem>
                                        <DropdownMenuItem onClick={() => openEditModal(course)}>
                                          <Edit className="w-4 h-4 mr-2" /> Edit
                                        </DropdownMenuItem>
                                        <DropdownMenuItem className="text-red-600" onClick={() => openDeleteModal(course)}>
                                          <Trash2 className="w-4 h-4 mr-2" /> Delete
                                        </DropdownMenuItem>
                                      </DropdownMenuContent>
                                    </DropdownMenu>
                                  </div>
                                </div>

                                <div className="p-5">
                                  {teacher && (
                                    <div className="flex items-center mb-3">
                                      <div className="w-6 h-6 bg-gray-200 rounded-full mr-2 flex items-center justify-center overflow-hidden">
                                        {teacher.profile_photo_url ? (
                                          <img src={teacher.profile_photo_url} alt={teacher.full_name} className="w-full h-full object-cover" />
                                        ) : (
                                          <span className="text-xs font-medium text-gray-600">
                                            {teacher.full_name?.[0]?.toUpperCase()}
                                          </span>
                                        )}
                                      </div>
                                      <span className="text-xs text-gray-600">Instructor-led</span>
                                    </div>
                                  )}

                                  <Link to={createPageUrl(`AdminCourseDetail?id=${course.id}`)}>
                                    <h3 className="text-lg font-bold text-gray-900 mb-2 hover:text-blue-600 transition-colors line-clamp-2 break-words min-h-[3.5rem]">
                                      {course.title}
                                    </h3>
                                  </Link>

                                  <p className="text-sm text-gray-600 mb-4 text-justify line-clamp-3 break-words min-h-[4.5rem]">
                                    {course.description || 'No description available'}
                                  </p>

                                  <div className="flex items-center justify-between text-sm text-gray-500 pt-4 border-t border-gray-100">
                                    <div className="flex items-center">
                                      <Clock className="w-4 h-4 mr-1" />
                                      <span>{course.duration_weeks || 0} Weeks</span>
                                    </div>
                                    <div className="flex items-center">
                                      <Play className="w-4 h-4 mr-1" />
                                      <span>{stats.videos} Videos</span>
                                    </div>
                                    <div className="flex items-center">
                                      <Users className="w-4 h-4 mr-1" />
                                      <span>{stats.students} Students</span>
                                    </div>
                                  </div>

                                  <div className="mt-3">
                                    <Badge variant="outline" className="text-xs capitalize">
                                      {course.category?.replace('-', ' ') || 'General'}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <Folder className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                          <p className="text-gray-500">No courses in this phase yet</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-2xl border-2 border-dashed border-gray-300 shadow-lg">
            <BookOpen className="w-20 h-20 text-gray-300 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-gray-900 mb-3">No Courses Yet</h3>
            <p className="text-gray-600 mb-8 text-lg">Get started by creating your first course</p>
            <Button onClick={openAddModal} size="lg" className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 text-white shadow-lg">
              <PlusCircle className="w-5 h-5 mr-2" /> Create First Course
            </Button>
          </div>
        )}
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">{editingCourse?.id ? 'Edit' : 'Add'} Course</DialogTitle>
          </DialogHeader>
          <div className="py-4">
            <CourseForm course={editingCourse} setCourse={setEditingCourse} teachers={teachers} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsModalOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700">Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Course</DialogTitle>
          </DialogHeader>
          <p className="text-gray-600">Are you sure you want to delete "{editingCourse?.title}"? This action cannot be undone.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Students to Phase Modal */}
      <Dialog open={isAssignStudentModalOpen} onOpenChange={setIsAssignStudentModalOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold">
              Assign Students to {selectedPhase?.replace('phase', 'Phase ')}
            </DialogTitle>
            <p className="text-gray-600 mt-2">
              Select students to assign to this phase. Students will only see courses from their assigned phase.
            </p>
          </DialogHeader>

          <div className="py-4">
            {selectedStudentIds.length > 0 && (
              <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                <p className="text-sm text-blue-800 font-medium">
                  {selectedStudentIds.length} student(s) selected
                </p>
              </div>
            )}

            <div className="space-y-2 max-h-[400px] overflow-y-auto">
              {allStudents.length > 0 ? (
                allStudents.map((student) => {
                  const isSelected = selectedStudentIds.includes(student.id);
                  const currentPhase = student.assigned_phase;
                  
                  return (
                    <div
                      key={student.id}
                      onClick={() => toggleStudentSelection(student.id)}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        isSelected
                          ? 'border-blue-500 bg-blue-50'
                          : 'border-gray-200 hover:border-blue-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <Checkbox
                          checked={isSelected}
                          onChange={() => {}}
                          className="pointer-events-none"
                        />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{student.full_name || 'Unnamed Student'}</p>
                          <p className="text-sm text-gray-500">{student.email}</p>
                          {currentPhase && (
                            <p className="text-xs text-gray-400 mt-1">
                              Current Phase: {currentPhase.replace('phase', 'Phase ')}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p>No students found</p>
                </div>
              )}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAssignStudentModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAssignStudents}
              disabled={selectedStudentIds.length === 0}
              className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700"
            >
              Assign to {selectedPhase?.replace('phase', 'Phase ')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
