import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Course } from '@/api/entities';
import { Enrollment } from '@/api/entities';
import { QuizAttempt } from '@/api/entities';
import { StudentProgress } from '@/api/entities';
import { getUserRole } from '../components/utils/getUserRole';
import { Trophy, TrendingUp, Award, Medal } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function StudentPerformance() {
  const [currentUser, setCurrentUser] = useState(null);
  const [students, setStudents] = useState([]);
  const [courses, setCourses] = useState([]);
  const [selectedCourse, setSelectedCourse] = useState('all');
  const [performanceData, setPerformanceData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (students.length > 0) {
      calculatePerformance();
    }
  }, [selectedCourse, students]);

  const loadData = async () => {
    setLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);

      const userRole = getUserRole(user);
      if (userRole !== 'admin' && userRole !== 'teacher') {
        window.location.href = '/';
        return;
      }

      const [allUsers, allCourses] = await Promise.all([
        User.list(),
        Course.list()
      ]);

      const studentUsers = allUsers.filter(u => getUserRole(u) === 'student');
      setStudents(studentUsers);
      setCourses(allCourses);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  const calculatePerformance = async () => {
    try {
      const [enrollments, quizAttempts, progress] = await Promise.all([
        Enrollment.list(),
        QuizAttempt.list(),
        StudentProgress.list()
      ]);

      const performance = students.map(student => {
        // Filter by course if selected
        const studentEnrollments = selectedCourse === 'all'
          ? enrollments.filter(e => e.student_id === student.id)
          : enrollments.filter(e => e.student_id === student.id && e.course_id === selectedCourse);

        if (studentEnrollments.length === 0) return null;

        // Calculate average progress
        const avgProgress = studentEnrollments.reduce((sum, e) => sum + (e.progress_percentage || 0), 0) / studentEnrollments.length;

        // Calculate quiz performance
        const studentQuizAttempts = quizAttempts.filter(a => 
          a.student_id === student.id && 
          a.status === 'completed' &&
          (selectedCourse === 'all' || studentEnrollments.some(e => e.course_id === selectedCourse))
        );

        const avgQuizScore = studentQuizAttempts.length > 0
          ? studentQuizAttempts.reduce((sum, a) => sum + (a.score || 0), 0) / studentQuizAttempts.length
          : 0;

        // Calculate completion rate
        const completedCourses = studentEnrollments.filter(e => e.progress_percentage >= 100).length;
        const completionRate = (completedCourses / studentEnrollments.length) * 100;

        // Calculate overall performance score (weighted average)
        const performanceScore = (avgProgress * 0.4) + (avgQuizScore * 0.4) + (completionRate * 0.2);

        return {
          student,
          avgProgress: Math.round(avgProgress),
          avgQuizScore: Math.round(avgQuizScore),
          completionRate: Math.round(completionRate),
          performanceScore: Math.round(performanceScore),
          coursesEnrolled: studentEnrollments.length,
          quizzesTaken: studentQuizAttempts.length
        };
      }).filter(p => p !== null);

      // Sort by performance score
      performance.sort((a, b) => b.performanceScore - a.performanceScore);

      setPerformanceData(performance);
    } catch (error) {
      console.error("Error calculating performance:", error);
    }
  };

  const getRankIcon = (rank) => {
    if (rank === 1) return <Trophy className="w-6 h-6 text-yellow-500" />;
    if (rank === 2) return <Medal className="w-6 h-6 text-gray-400" />;
    if (rank === 3) return <Medal className="w-6 h-6 text-orange-600" />;
    return <Award className="w-6 h-6 text-gray-300" />;
  };

  const getPerformanceColor = (score) => {
    if (score >= 80) return 'text-green-600 bg-green-50';
    if (score >= 60) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-gray-900">Student Performance</h1>
            <Select value={selectedCourse} onValueChange={setSelectedCourse}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Filter by Course" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Courses</SelectItem>
                {courses.map(course => (
                  <SelectItem key={course.id} value={course.id}>{course.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Top 3 Students */}
        {performanceData.length >= 3 && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {performanceData.slice(0, 3).map((data, index) => (
              <div
                key={data.student.id}
                className={`bg-white rounded-xl shadow-lg border-2 p-6 text-center ${
                  index === 0 ? 'border-yellow-400' :
                  index === 1 ? 'border-gray-400' :
                  'border-orange-400'
                }`}
              >
                <div className="flex justify-center mb-4">
                  {getRankIcon(index + 1)}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{data.student.full_name}</h3>
                <div className={`inline-block px-4 py-2 rounded-full text-2xl font-bold ${getPerformanceColor(data.performanceScore)}`}>
                  {data.performanceScore}%
                </div>
                <div className="mt-4 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-gray-500">Avg Progress</p>
                    <p className="font-semibold">{data.avgProgress}%</p>
                  </div>
                  <div>
                    <p className="text-gray-500">Avg Quiz Score</p>
                    <p className="font-semibold">{data.avgQuizScore}%</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* All Students Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="p-6 border-b">
            <h2 className="text-xl font-bold text-gray-900">Performance Rankings</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Rank
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Student
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Performance Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg Progress
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Avg Quiz Score
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Completion Rate
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Courses
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Quizzes Taken
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {performanceData.map((data, index) => (
                  <tr key={data.student.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {getRankIcon(index + 1)}
                        <span className="ml-2 font-semibold">#{index + 1}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium text-gray-900">{data.student.full_name}</div>
                      <div className="text-sm text-gray-500">{data.student.email}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getPerformanceColor(data.performanceScore)}`}>
                        {data.performanceScore}%
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {data.avgProgress}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {data.avgQuizScore}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {data.completionRate}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {data.coursesEnrolled}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {data.quizzesTaken}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}