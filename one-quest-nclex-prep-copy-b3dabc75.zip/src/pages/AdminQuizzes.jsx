
import React, { useState, useEffect } from 'react';
import { Quiz } from '@/api/entities';
import { Course } from '@/api/entities';
import { Video } from '@/api/entities';
import { QuizAttempt } from '@/api/entities';
import { User } from '@/api/entities';
import { Section } from '@/api/entities';
import { Module } from '@/api/entities'; // Added: Module entity import
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PlusCircle, MoreHorizontal, Edit, Trash2, Users, FileText, X, GripVertical, Plus } from 'lucide-react';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { getUserRole } from '../components/utils/getUserRole';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Link } from 'react-router-dom';

const QuestionManager = ({ questions = [], setQuestions, videos = [] }) => {
  const addQuestion = (type = 'multiple_choice') => {
    const newQuestion = {
      question: '',
      question_type: type,
      options: ['', ''],
      correct_answer: [],
      explanation: '',
      points: 1,
      required_answers_count: 1
    };

    if (type === 'matrix') {
      newQuestion.matrix_rows = [''];
      newQuestion.matrix_columns = ['', ''];
      newQuestion.matrix_correct_answers = {};
    } else if (type === 'ranking') {
      newQuestion.ranking_correct_order = []; // Will be set automatically on save from options
    }

    setQuestions([...questions, newQuestion]);
  };

  const removeQuestion = (index) => setQuestions(questions.filter((_, i) => i !== index));

  const handleQuestionChange = (qIndex, field, value) => {
    const newQuestions = [...questions];
    newQuestions[qIndex][field] = value;
    
    // Initialize matrix properties when switching to matrix type
    if (field === 'question_type' && value === 'matrix') {
      if (!newQuestions[qIndex].matrix_rows) {
        newQuestions[qIndex].matrix_rows = [''];
      }
      if (!newQuestions[qIndex].matrix_columns) {
        newQuestions[qIndex].matrix_columns = ['', ''];
      }
      if (!newQuestions[qIndex].matrix_correct_answers) {
        newQuestions[qIndex].matrix_correct_answers = {};
      }
    }
    
    // Initialize ranking properties when switching to ranking type
    if (field === 'question_type' && value === 'ranking') {
      if (!newQuestions[qIndex].ranking_correct_order) {
        newQuestions[qIndex].ranking_correct_order = [];
      }
    }
    
    setQuestions(newQuestions);
  };

  const handleOptionChange = (qIndex, oIndex, value) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].options[oIndex] = value;
    setQuestions(newQuestions);
  };

  const addOption = (qIndex) => {
    const newQuestions = [...questions];
    newQuestions[qIndex].options.push('');
    setQuestions(newQuestions);
  };

  const removeOption = (qIndex, oIndex) => {
    const newQuestions = [...questions];
    if (newQuestions[qIndex].options.length > 2) {
      // Remove option from options array
      newQuestions[qIndex].options.splice(oIndex, 1);

      // Adjust correct_answer indices for multiple_choice
      if (newQuestions[qIndex].question_type === 'multiple_choice') {
        newQuestions[qIndex].correct_answer = newQuestions[qIndex].correct_answer
          .filter(idx => idx !== oIndex) // Remove the deleted option if it was correct
          .map(idx => (idx > oIndex ? idx - 1 : idx)); // Shift indices down for options after the deleted one
      }
      setQuestions(newQuestions);
    }
  };

  const toggleCorrectAnswer = (qIndex, oIndex) => {
    const newQuestions = [...questions];
    const question = newQuestions[qIndex];
    
    if (!Array.isArray(question.correct_answer)) {
      question.correct_answer = [];
    }

    const requiredCount = question.required_answers_count || 1; // Get required count
    const answerIndex = question.correct_answer.indexOf(oIndex);
    
    if (answerIndex > -1) {
      // If already selected, deselect it
      question.correct_answer.splice(answerIndex, 1);
    } else {
      // If not selected
      if (requiredCount === 1) {
        // If only 1 answer is required, replace the existing answer
        question.correct_answer = [oIndex];
      } else {
        // Allow multiple selections up to required count
        if (question.correct_answer.length < requiredCount) {
          question.correct_answer.push(oIndex);
        }
      }
    }
    
    setQuestions(newQuestions);
  };

  const addMatrixRow = (qIndex) => {
    const newQuestions = [...questions];
    // Ensure matrix_rows exists and is an array
    if (!newQuestions[qIndex].matrix_rows) {
      newQuestions[qIndex].matrix_rows = [];
    }
    newQuestions[qIndex].matrix_rows.push('');
    setQuestions(newQuestions);
  };

  const removeMatrixRow = (qIndex, rIndex) => {
    const newQuestions = [...questions];
    // Ensure matrix_rows exists before checking length
    if (newQuestions[qIndex].matrix_rows && newQuestions[qIndex].matrix_rows.length > 1) {
      newQuestions[qIndex].matrix_rows.splice(rIndex, 1);

      const oldCorrectAnswers = newQuestions[qIndex].matrix_correct_answers || {};
      const newCorrectAnswers = {};
      Object.keys(oldCorrectAnswers).forEach(key => {
        const numKey = parseInt(key, 10);
        if (numKey < rIndex) {
          newCorrectAnswers[numKey] = oldCorrectAnswers[key];
        } else if (numKey > rIndex) {
          newCorrectAnswers[numKey - 1] = oldCorrectAnswers[key];
        }
        // If numKey === rIndex, it's deleted, so don't include it in newCorrectAnswers
      });
      newQuestions[qIndex].matrix_correct_answers = newCorrectAnswers;
      setQuestions(newQuestions);
    }
  };

  const addMatrixColumn = (qIndex) => {
    const newQuestions = [...questions];
    // Ensure matrix_columns exists and is an array
    if (!newQuestions[qIndex].matrix_columns) {
      newQuestions[qIndex].matrix_columns = [];
    }
    newQuestions[qIndex].matrix_columns.push('');
    setQuestions(newQuestions);
  };

  const removeMatrixColumn = (qIndex, cIndex) => {
    const newQuestions = [...questions];
    // Ensure matrix_columns exists before checking length
    if (newQuestions[qIndex].matrix_columns && newQuestions[qIndex].matrix_columns.length > 2) {
      newQuestions[qIndex].matrix_columns.splice(cIndex, 1);

      const oldCorrectAnswers = newQuestions[qIndex].matrix_correct_answers || {};
      const newCorrectAnswers = {};
      Object.keys(oldCorrectAnswers).forEach(rowKey => {
        const colIndex = oldCorrectAnswers[rowKey];
        if (colIndex < cIndex) {
          newCorrectAnswers[rowKey] = colIndex;
        } else if (colIndex > cIndex) {
          newCorrectAnswers[rowKey] = colIndex - 1;
        }
        // If colIndex === cIndex, it's deleted, so don't include it in newCorrectAnswers
      });
      newQuestions[qIndex].matrix_correct_answers = newCorrectAnswers;
      setQuestions(newQuestions);
    }
  };

  const handleMatrixCorrectAnswer = (qIndex, rowIndex, columnIndex) => {
    const newQuestions = [...questions];
    if (!newQuestions[qIndex].matrix_correct_answers) {
      newQuestions[qIndex].matrix_correct_answers = {};
    }
    newQuestions[qIndex].matrix_correct_answers[rowIndex] = columnIndex;
    setQuestions(newQuestions);
  };

  return (
    <div className="space-y-6 max-h-[500px] overflow-y-auto pr-2">
      {questions.map((q, qIndex) => (
        <div key={qIndex} className="p-4 border-2 border-gray-200 rounded-lg space-y-3 relative bg-white">
          <button
            onClick={() => removeQuestion(qIndex)}
            className="absolute top-2 right-2 text-red-500 hover:text-red-700 p-1"
          >
            <X size={18} />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <GripVertical size={20} className="text-gray-400" />
            <span className="font-semibold text-gray-700">Question {qIndex + 1}</span>
          </div>

          {/* Points and Required Answers */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-sm">Points</Label>
              <Input
                type="number"
                min="1"
                value={q.points || 1}
                onChange={(e) => handleQuestionChange(qIndex, 'points', parseInt(e.target.value) || 1)}
                placeholder="Points"
              />
            </div>
            {q.question_type === 'multiple_choice' && (
              <div>
                <Label className="text-sm">Required Answers</Label>
                <Input
                  type="number"
                  min="1"
                  max={q.options?.length || 2}
                  value={q.required_answers_count || 1}
                  onChange={(e) => {
                    const val = parseInt(e.target.value) || 1;
                    handleQuestionChange(qIndex, 'required_answers_count', val);
                    // Reset correct answers if count changes
                    const newQuestions = [...questions];
                    newQuestions[qIndex].correct_answer = [];
                    setQuestions(newQuestions);
                  }}
                  placeholder="How many?"
                />
                <p className="text-xs text-gray-500 mt-1">
                  {q.required_answers_count === 1 ? 'Students must select only 1 answer' : `Students must select ${q.required_answers_count} answers`}
                </p>
              </div>
            )}
          </div>

          <Select
            value={q.question_type || 'multiple_choice'}
            onValueChange={(val) => handleQuestionChange(qIndex, 'question_type', val)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Question Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
              <SelectItem value="matrix">Matrix / Checkbox Grid</SelectItem>
              <SelectItem value="ranking">Ordered Response / Ranking</SelectItem>
            </SelectContent>
          </Select>

          <Textarea
            placeholder="Question text"
            value={q.question}
            onChange={(e) => handleQuestionChange(qIndex, 'question', e.target.value)}
            className="min-h-[80px]"
          />

          {/* Multiple Choice Questions */}
          {q.question_type === 'multiple_choice' && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                Answer Options (select {q.required_answers_count || 1} correct answer{(q.required_answers_count || 1) > 1 ? 's' : ''})
              </Label>
              {(q.options || []).map((opt, oIndex) => (
                <div key={oIndex} className="flex items-center gap-2">
                  <Checkbox
                    checked={Array.isArray(q.correct_answer) && q.correct_answer.includes(oIndex)}
                    onCheckedChange={() => toggleCorrectAnswer(qIndex, oIndex)}
                    disabled={(q.correct_answer || []).length >= (q.required_answers_count || 1) && !q.correct_answer.includes(oIndex)}
                  />
                  <Input
                    placeholder={`Option ${oIndex + 1}`}
                    value={opt}
                    onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
                    className="flex-1"
                  />
                  {(q.options || []).length > 2 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeOption(qIndex, oIndex)}
                      className="text-red-500"
                    >
                      <X size={16} />
                    </Button>
                  )}
                </div>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => addOption(qIndex)}
                className="w-full"
              >
                <Plus size={16} className="mr-2" /> Add Option
              </Button>
            </div>
          )}

          {/* Matrix Questions */}
          {q.question_type === 'matrix' && (
            <div className="space-y-3">
              <div>
                <Label className="text-sm font-medium mb-2 block">Row Labels</Label>
                {(q.matrix_rows || []).map((row, rIndex) => (
                  <div key={rIndex} className="flex gap-2 mb-2">
                    <Input
                      placeholder={`Row ${rIndex + 1}`}
                      value={row}
                      onChange={(e) => {
                        const newQuestions = [...questions];
                        // Ensure matrix_rows exists before updating
                        if (!newQuestions[qIndex].matrix_rows) {
                          newQuestions[qIndex].matrix_rows = [];
                        }
                        newQuestions[qIndex].matrix_rows[rIndex] = e.target.value;
                        setQuestions(newQuestions);
                      }}
                    />
                    {(q.matrix_rows || []).length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeMatrixRow(qIndex, rIndex)}
                      >
                        <X size={16} />
                      </Button>
                    )}
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => addMatrixRow(qIndex)}>
                  <Plus size={16} className="mr-2" /> Add Row
                </Button>
              </div>

              <div>
                <Label className="text-sm font-medium mb-2 block">Column Labels</Label>
                {(q.matrix_columns || []).map((col, cIndex) => (
                  <div key={cIndex} className="flex gap-2 mb-2">
                    <Input
                      placeholder={`Column ${cIndex + 1}`}
                      value={col}
                      onChange={(e) => {
                        const newQuestions = [...questions];
                        // Ensure matrix_columns exists before updating
                        if (!newQuestions[qIndex].matrix_columns) {
                          newQuestions[qIndex].matrix_columns = [];
                        }
                        newQuestions[qIndex].matrix_columns[cIndex] = e.target.value;
                        setQuestions(newQuestions);
                      }}
                    />
                    {(q.matrix_columns || []).length > 2 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeMatrixColumn(qIndex, cIndex)}
                      >
                        <X size={16} />
                      </Button>
                    )}
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => addMatrixColumn(qIndex)}>
                  <Plus size={16} className="mr-2" /> Add Column
                </Button>
              </div>

              {/* Matrix Correct Answers Grid */}
              {q.matrix_rows && q.matrix_rows.length > 0 && q.matrix_columns && q.matrix_columns.length > 0 && (
                <div className="border rounded-lg p-4 bg-blue-50">
                  <Label className="text-sm font-medium mb-3 block">Select Correct Answer for Each Row</Label>
                  <div className="space-y-3">
                    {q.matrix_rows.map((row, rIndex) => (
                      <div key={rIndex} className="bg-white rounded p-3">
                        <p className="text-sm font-medium text-gray-700 mb-2">{row || `Row ${rIndex + 1}`}</p>
                        <Select
                          value={q.matrix_correct_answers?.[rIndex]?.toString() || ''}
                          onValueChange={(value) => handleMatrixCorrectAnswer(qIndex, rIndex, parseInt(value, 10))}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select correct column" />
                          </SelectTrigger>
                          <SelectContent>
                            {q.matrix_columns.map((col, cIndex) => (
                              <SelectItem key={cIndex} value={cIndex.toString()}>
                                {col || `Column ${cIndex + 1}`}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Ranking Questions */}
          {q.question_type === 'ranking' && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Items to Rank (in correct order)</Label>
              {(q.options || []).map((opt, oIndex) => (
                <div key={oIndex} className="flex items-center gap-2">
                  <GripVertical size={16} className="text-gray-400" />
                  <span className="text-sm font-medium text-gray-500 w-6">{oIndex + 1}.</span>
                  <Input
                    placeholder={`Item ${oIndex + 1}`}
                    value={opt}
                    onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
                    className="flex-1"
                  />
                  {(q.options || []).length > 2 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeOption(qIndex, oIndex)}
                      className="text-red-500"
                    >
                      <X size={16} />
                    </Button>
                  )}
                </div>
              ))}
              <Button
                variant="outline"
                size="sm"
                onClick={() => addOption(qIndex)}
                className="w-full"
              >
                <Plus size={16} className="mr-2" /> Add Item
              </Button>
              <p className="text-xs text-gray-500">Students will need to arrange these in the correct order shown above</p>
            </div>
          )}

          <Textarea
            placeholder="Explanation (shown after answer)"
            value={q.explanation || ''}
            onChange={(e) => handleQuestionChange(qIndex, 'explanation', e.target.value)}
            className="min-h-[60px]"
          />
        </div>
      ))}

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="w-full">
            <PlusCircle size={16} className="mr-2" /> Add Question
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent>
          <DropdownMenuItem onClick={() => addQuestion('multiple_choice')}>
            Multiple Choice
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => addQuestion('matrix')}>
            Matrix / Checkbox Grid
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => addQuestion('ranking')}>
            Ordered Response / Ranking
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

const QuizForm = ({ quiz, setQuiz, videos, modules, courses }) => {
  const [courseVideos, setCourseVideos] = useState([]);
  const [availableModulesForCourse, setAvailableModulesForCourse] = useState([]);

  useEffect(() => {
    if (quiz?.course_id) {
      const filteredVideos = videos.filter(v => v.course_id === quiz.course_id);
      setCourseVideos(filteredVideos);
      
      const filteredModules = modules.filter(m => m.course_id === quiz.course_id);
      setAvailableModulesForCourse(filteredModules);
    } else {
      setCourseVideos([]);
      setAvailableModulesForCourse([]);
    }
  }, [quiz?.course_id, videos, modules]);

  const safeQuiz = quiz || {};

  return (
    <div className="space-y-4">
      <Input
        placeholder="Quiz Title"
        value={safeQuiz.title || ''}
        onChange={(e) => setQuiz({...safeQuiz, title: e.target.value})}
      />
      <Textarea
        placeholder="Description"
        value={safeQuiz.description || ''}
        onChange={(e) => setQuiz({...safeQuiz, description: e.target.value})}
      />
      
      <div>
        <Label className="text-sm font-medium mb-2 block">Start Date & Time (Optional)</Label>
        <Input
          type="datetime-local"
          value={safeQuiz.start_date ? new Date(safeQuiz.start_date).toISOString().slice(0, 16) : ''}
          onChange={(e) => setQuiz({...safeQuiz, start_date: e.target.value ? new Date(e.target.value).toISOString() : null})}
        />
        <p className="text-xs text-gray-500 mt-1">Quiz will only be available after this date/time</p>
      </div>

      <div className="flex items-center space-x-2">
        <Checkbox
          id="requires_video"
          checked={safeQuiz.requires_video_completion || false}
          onCheckedChange={(checked) => setQuiz({...safeQuiz, requires_video_completion: checked})}
        />
        <Label htmlFor="requires_video" className="text-sm font-medium cursor-pointer">
          Require video completion before taking quiz
        </Label>
      </div>

      {safeQuiz.requires_video_completion && courseVideos.length > 0 && (
        <div className="border rounded-lg p-3 space-y-2">
          <Label className="text-sm font-medium">Select Required Videos</Label>
          {courseVideos.map(video => (
            <div key={video.id} className="flex items-center space-x-2">
              <Checkbox
                id={`video-${video.id}`}
                checked={safeQuiz.prerequisite_video_ids?.includes(video.id) || false}
                onCheckedChange={(checked) => {
                  const currentIds = safeQuiz.prerequisite_video_ids || [];
                  const newIds = checked
                    ? [...currentIds, video.id]
                    : currentIds.filter(id => id !== video.id);
                  setQuiz({...safeQuiz, prerequisite_video_ids: newIds});
                }}
              />
              <Label htmlFor={`video-${video.id}`} className="text-sm cursor-pointer">
                {video.title}
              </Label>
            </div>
          ))}
        </div>
      )}

      {safeQuiz.requires_video_completion && courseVideos.length === 0 && safeQuiz.course_id && (
        <div className="border border-orange-200 bg-orange-50 rounded-lg p-3">
          <p className="text-sm text-orange-800">
            No videos available in this course. Add videos first or disable video requirement.
          </p>
        </div>
      )}

      <Input
        type="number"
        placeholder="Time Limit (minutes)"
        value={safeQuiz.time_limit_minutes || ''}
        onChange={(e) => setQuiz({...safeQuiz, time_limit_minutes: Number(e.target.value) || null})}
      />
      <Input
        type="number"
        placeholder="Passing Score (%)"
        value={safeQuiz.passing_score || ''}
        onChange={(e) => setQuiz({...safeQuiz, passing_score: Number(e.target.value) || null})}
      />
      <div>
        <Input
          type="number"
          placeholder="Max Attempts"
          value={safeQuiz.max_attempts || ''}
          onChange={(e) => setQuiz({...safeQuiz, max_attempts: Number(e.target.value) || null})}
        />
        <p className="text-xs text-gray-500 mt-1">Leave blank or enter 0 for unlimited attempts.</p>
      </div>
      <QuestionManager
        questions={safeQuiz.questions || []}
        setQuestions={(qs) => setQuiz({...safeQuiz, questions: qs})}
        videos={courseVideos}
      />
    </div>
  );
};

export default function AdminQuizzes() {
  const [quizzes, setQuizzes] = useState([]);
  const [courses, setCourses] = useState([]);
  const [videos, setVideos] = useState([]);
  const [sections, setSections] = useState([]);
  const [modules, setModules] = useState([]); // Added: New state for modules
  const [quizStats, setQuizStats] = useState({});
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState(null);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [saveError, setSaveError] = useState('');
  const [preselectedSectionId, setPreselectedSectionId] = useState(null);
  
  // Filters
  const [selectedCourse, setSelectedCourse] = useState('all');
  const [selectedModule, setSelectedModule] = useState('all');

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const sectionId = urlParams.get('section_id');
    if (sectionId) {
      setPreselectedSectionId(sectionId);
    }
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);

      if (getUserRole(user) !== 'admin') {
        window.location.href = '/';
        return;
      }

      const [allQuizzes, allCourses, allVideos, allAttempts, allSections, allModules] = await Promise.all([
        Quiz.list(),
        Course.list(),
        Video.list(),
        QuizAttempt.list(),
        Section.list(),
        Module.list() // Added: Load modules
      ]);
      setQuizzes(allQuizzes);
      setCourses(allCourses);
      setVideos(allVideos);
      setSections(allSections);
      setModules(allModules); // Added: Set modules state

      const stats = allAttempts.reduce((acc, attempt) => {
        if (!acc[attempt.quiz_id]) acc[attempt.quiz_id] = new Set();
        acc[attempt.quiz_id].add(attempt.student_id);
        return acc;
      }, {});
      setQuizStats(stats);

    } catch (error) {
      console.error("Error loading data:", error);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    if (!editingQuiz) return;
    
    setSaveError('');
    
    if (!editingQuiz.title || editingQuiz.title.trim() === '') {
      setSaveError('Quiz title is required.');
      return;
    }
    
    if (!editingQuiz.course_id) {
      setSaveError('Please select a course for the quiz.');
      return;
    }

    // New: Validate module_id if course_id is set and modules exist for that course
    const modulesForCourse = modules.filter(m => m.course_id === editingQuiz.course_id);
    if (modulesForCourse.length > 0 && !editingQuiz.module_id) {
        setSaveError('Please assign the quiz to a module within the selected course, or select a course without modules.');
        return;
    }
    
    if (!editingQuiz.questions || editingQuiz.questions.length === 0) {
      setSaveError('Please add at least one question to the quiz.');
      return;
    }
    
    for (let i = 0; i < editingQuiz.questions.length; i++) {
      const q = editingQuiz.questions[i];

      if (!q.question || q.question.trim() === '') {
        setSaveError(`Question ${i + 1} is missing the question text.`);
        return;
      }

      if (!q.points || q.points < 1) {
        setSaveError(`Question ${i + 1} must have at least 1 point.`);
        return;
      }
      
      if (q.question_type === 'multiple_choice') {
        if (!q.options || q.options.length < 2 || q.options.some(opt => opt.trim() === '')) {
          setSaveError(`Question ${i + 1} needs at least 2 non-empty answer options.`);
          return;
        }
        
        const requiredAnswers = q.required_answers_count || 1;
        if (requiredAnswers < 1 || requiredAnswers > q.options.length) {
          setSaveError(`Question ${i + 1}: Required answers count must be between 1 and the number of options (${q.options.length}).`);
          return;
        }

        if (!q.correct_answer || q.correct_answer.length === 0) {
          setSaveError(`Question ${i + 1} needs at least one correct answer selected.`);
          return;
        }

        if (q.correct_answer.length !== requiredAnswers) {
          setSaveError(`Question ${i + 1}: Please select exactly ${requiredAnswers} correct answer(s).`);
          return;
        }

      } else if (q.question_type === 'matrix') {
        if (!q.matrix_rows || (q.matrix_rows || []).length === 0 || (q.matrix_rows || []).some(row => row.trim() === '')) {
          setSaveError(`Question ${i + 1} needs at least one non-empty row label.`);
          return;
        }
        if (!q.matrix_columns || (q.matrix_columns || []).length < 2 || (q.matrix_columns || []).some(col => col.trim() === '')) {
          setSaveError(`Question ${i + 1} needs at least 2 non-empty column labels.`);
          return;
        }
        if (!q.matrix_correct_answers) {
          setSaveError(`Question ${i + 1}: Please select a correct column for each row in the matrix.`);
          return;
        }
        for (let r = 0; r < q.matrix_rows.length; r++) {
            if (!(r in q.matrix_correct_answers) || q.matrix_correct_answers[r] === null || q.matrix_correct_answers[r] === undefined) {
                setSaveError(`Question ${i + 1}: Please select a correct column for row "${q.matrix_rows[r] || `Row ${r + 1}`}".`);
                return;
            }
            if (q.matrix_correct_answers[r] < 0 || q.matrix_correct_answers[r] >= q.matrix_columns.length) {
                 setSaveError(`Question ${i + 1}: Invalid correct column selection for row "${q.matrix_rows[r] || `Row ${r + 1}`}".`);
                 return;
            }
        }
      } else if (q.question_type === 'ranking') {
        if (!q.options || (q.options || []).length < 2 || (q.options || []).some(opt => opt.trim() === '')) {
          setSaveError(`Question ${i + 1} needs at least 2 non-empty items to rank.`);
          return;
        }
      }
    }
    
    try {
      const quizData = { ...editingQuiz };
      
      quizData.questions = quizData.questions.map(q => {
        if (q.question_type === 'ranking') {
          q.ranking_correct_order = (q.options || []).map((_, index) => index);
        }
        // Filter out empty options/rows/columns before saving
        if (q.options) q.options = q.options.filter(opt => opt.trim() !== '');
        if (q.matrix_rows) q.matrix_rows = q.matrix_rows.filter(row => row.trim() !== '');
        if (q.matrix_columns) q.matrix_columns = q.matrix_columns.filter(col => col.trim() !== '');
        return q;
      });

      // Set number fields to null if empty
      if (!quizData.time_limit_minutes) quizData.time_limit_minutes = null;
      if (!quizData.passing_score) quizData.passing_score = null;
      if (!quizData.max_attempts) quizData.max_attempts = null;
      
      // Handle prerequisite_video_ids based on requires_video_completion
      if (quizData.prerequisite_video_ids && quizData.prerequisite_video_ids.length === 0) quizData.prerequisite_video_ids = null;
      if (!quizData.requires_video_completion) {
        quizData.prerequisite_video_ids = null;
      }

      if (quizData.id) {
        await Quiz.update(quizData.id, quizData);
      } else {
        await Quiz.create(quizData);
      }
      await loadData();
      setIsModalOpen(false);
      setEditingQuiz(null);
      setSaveError('');
    } catch (error) {
      console.error("Error saving quiz:", error);
      setSaveError(error.message || 'Failed to save quiz. Please check all required fields.');
    }
  };

  const handleDelete = async () => {
    if (!editingQuiz) return;
    try {
      await Quiz.delete(editingQuiz.id);
      await loadData();
      setIsDeleteModalOpen(false);
      setEditingQuiz(null);
    } catch (error) {
      console.error("Error deleting quiz:", error);
    }
  };

  const openAddModal = () => {
    setEditingQuiz({ 
      title: '',
      description: '',
      course_id: '',
      module_id: null, // Added: New: Default module_id
      section_id: preselectedSectionId || null,
      questions: [],
      time_limit_minutes: 30,
      passing_score: 60,
      max_attempts: 3,
      requires_video_completion: false,
      prerequisite_video_ids: [],
      start_date: null
    });
    setSaveError('');
    setIsModalOpen(true);
  };

  const openEditModal = (quiz) => {
    setEditingQuiz({...quiz});
    setSaveError('');
    setIsModalOpen(true);
  };

  const openDeleteModal = (quiz) => {
    setEditingQuiz({...quiz});
    setIsDeleteModalOpen(true);
  };

  const getCourseTitle = (courseId) => courses.find(c => c.id === courseId)?.title || 'N/A';
  const getModuleTitle = (moduleId) => modules.find(m => m.id === moduleId)?.title || 'N/A'; // Added: Helper to get module name

  const createPageUrl = (pageNameAndParams) => {
    return `/${pageNameAndParams}`;
  };

  // Filter quizzes
  const filteredQuizzes = quizzes.filter(quiz => {
    if (selectedCourse !== 'all' && quiz.course_id !== selectedCourse) return false;
    if (selectedModule !== 'all' && quiz.module_id !== selectedModule) return false;
    return true;
  });

  // Get modules for selected course
  const availableModules = selectedCourse !== 'all' 
    ? modules.filter(m => m.course_id === selectedCourse)
    : []; // Changed to empty array if no course selected

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 via-purple-50 to-pink-50">
        <p className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent animate-pulse">Loading quizzes...</p>
      </div>
    );
  }

  if (currentUser && getUserRole(currentUser) !== 'admin') {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-purple-50 to-pink-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">Quiz Management</h1>
            <p className="text-gray-600 mt-2 text-lg">Create and manage course assessments</p>
          </div>
          <Button onClick={openAddModal} className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg">
            <PlusCircle className="w-5 h-5 mr-2" /> Add Quiz
          </Button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6 border-2 border-purple-100">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <Label className="text-sm font-semibold text-gray-700 mb-2 block">Filter by Course</Label>
              <Select value={selectedCourse} onValueChange={(value) => {
                setSelectedCourse(value);
                setSelectedModule('all');
              }}>
                <SelectTrigger className="border-2 border-gray-200 focus:border-purple-500">
                  <SelectValue placeholder="All Courses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Courses</SelectItem>
                  {courses.map(course => (
                    <SelectItem key={course.id} value={course.id}>{course.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex-1 min-w-[200px]">
              <Label className="text-sm font-semibold text-gray-700 mb-2 block">Filter by Module</Label>
              <Select 
                value={selectedModule} 
                onValueChange={setSelectedModule}
                disabled={selectedCourse === 'all' || availableModules.length === 0}
              >
                <SelectTrigger className="border-2 border-gray-200 focus:border-purple-500">
                  <SelectValue placeholder="All Modules" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Modules</SelectItem>
                  {availableModules.map(module => (
                    <SelectItem key={module.id} value={module.id}>{module.title}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border-2 border-purple-100 overflow-hidden">
          <div className="bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-4">
            <h2 className="text-xl font-bold text-white">All Quizzes</h2>
          </div>
          <Table>
            <TableHeader>
              <TableRow className="bg-gray-50 border-b-2 border-gray-200">
                <TableHead className="font-bold text-gray-900">Title</TableHead>
                <TableHead className="font-bold text-gray-900">Course</TableHead>
                <TableHead className="font-bold text-gray-900">Module</TableHead> {/* Added: New Module column */}
                <TableHead className="font-bold text-gray-900">Questions</TableHead>
                <TableHead className="font-bold text-gray-900">Type</TableHead>
                <TableHead className="font-bold text-gray-900">Participants</TableHead>
                <TableHead className="text-right font-bold text-gray-900">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredQuizzes.length > 0 ? ( // Changed from quizzes to filteredQuizzes
                filteredQuizzes.map((quiz) => {
                  const questionTypes = quiz.questions?.map(q => q.question_type || 'multiple_choice');
                  const hasMultipleTypes = new Set(questionTypes).size > 1;
                  return (
                    <TableRow key={quiz.id} className="hover:bg-purple-50 transition-colors">
                      <TableCell className="font-semibold">
                        <Link 
                          to={createPageUrl(`QuizPreview?id=${quiz.id}`)}
                          className="text-purple-600 hover:text-purple-800 hover:underline"
                        >
                          {quiz.title}
                        </Link>
                      </TableCell>
                      <TableCell>{getCourseTitle(quiz.course_id)}</TableCell>
                      <TableCell>{quiz.module_id ? getModuleTitle(quiz.module_id) : '-'}</TableCell> {/* Display Module name */}
                      <TableCell>
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                          {quiz.questions?.length || 0} questions
                        </span>
                      </TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                          hasMultipleTypes ? 'bg-purple-100 text-purple-800' : 
                          questionTypes[0] === 'matrix' ? 'bg-green-100 text-green-800' :
                          questionTypes[0] === 'ranking' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {hasMultipleTypes ? 'Mixed' : (questionTypes[0] === 'matrix' ? 'Matrix' : questionTypes[0] === 'ranking' ? 'Ranking' : 'Multiple Choice')}
                        </span>
                      </TableCell>
                      <TableCell className="flex items-center">
                        <Users className="w-4 h-4 mr-2 text-gray-500" /> 
                        <span className="font-semibold">{quizStats[quiz.id]?.size || 0}</span>
                      </TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-5 w-5" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Link to={createPageUrl(`QuizPreview?id=${quiz.id}`)} className="flex items-center w-full">
                                <FileText className="w-4 h-4 mr-2" /> Preview
                              </Link>
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => openEditModal(quiz)}>
                              <Edit className="w-4 h-4 mr-2" /> Edit
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-red-600" onClick={() => openDeleteModal(quiz)}>
                              <Trash2 className="w-4 h-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow><TableCell colSpan={7} className="text-center py-10 text-gray-500"> {/* Colspan adjusted */}
                  {selectedCourse !== 'all' || selectedModule !== 'all' ? 'No quizzes match the selected filters.' : 'No quizzes found.'}
                </TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingQuiz?.id ? 'Edit' : 'Add'} Quiz</DialogTitle></DialogHeader>
          
          {saveError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start">
              <X className="w-5 h-5 text-red-500 mr-2 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm text-red-800 font-medium">Error saving quiz</p>
                <p className="text-sm text-red-700">{saveError}</p>
              </div>
            </div>
          )}
          
          <div className="py-4 space-y-4">
            <Select 
              value={editingQuiz?.course_id || ''} 
              onValueChange={(value) => {
                setEditingQuiz({...editingQuiz, course_id: value, module_id: null}); // Reset module when course changes
              }}
            >
              <SelectTrigger className={!editingQuiz?.course_id ? 'border-red-300' : ''}>
                <SelectValue placeholder="Select Course *" />
              </SelectTrigger>
              <SelectContent>
                {courses.map(course => <SelectItem key={course.id} value={course.id}>{course.title}</SelectItem>)}
              </SelectContent>
            </Select>
            {!editingQuiz?.course_id && (
              <p className="text-xs text-red-500 mt-1">Please select a course</p>
            )}

            {/* New: Module selection */}
            <Select 
              value={editingQuiz?.module_id || ''} 
              onValueChange={(value) => setEditingQuiz({...editingQuiz, module_id: value})}
              disabled={!editingQuiz?.course_id || modules.filter(m => m.course_id === editingQuiz.course_id).length === 0}
            >
              <SelectTrigger className={modules.filter(m => m.course_id === editingQuiz?.course_id).length > 0 && !editingQuiz?.module_id ? 'border-red-300' : ''}>
                <SelectValue placeholder="Assign to Module (Optional)" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>No Module</SelectItem> {/* Option to not assign to a module */}
                {modules
                  .filter(m => m.course_id === editingQuiz?.course_id)
                  .map(module => (
                    <SelectItem key={module.id} value={module.id}>{module.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {modules.filter(m => m.course_id === editingQuiz?.course_id).length > 0 && !editingQuiz?.module_id && (
              <p className="text-xs text-red-500 mt-1">Please assign a module if one is available for the selected course, or select "No Module".</p>
            )}

            <Select 
              value={editingQuiz?.section_id || ''} 
              onValueChange={(value) => setEditingQuiz({...editingQuiz, section_id: value})}
            >
              <SelectTrigger><SelectValue placeholder="Select Section (Optional)" /></SelectTrigger>
              <SelectContent>
                <SelectItem value={null}>No Section</SelectItem>
                {sections
                  .filter(s => s.section_type === 'quiz' || s.section_type === 'other')
                  .map(section => (
                  <SelectItem key={section.id} value={section.id}>{section.title}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <QuizForm
              quiz={editingQuiz}
              setQuiz={setEditingQuiz}
              videos={videos}
              modules={modules} // Pass modules to QuizForm
              courses={courses} // Pass courses to QuizForm
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsModalOpen(false);
              setSaveError('');
            }}>Cancel</Button>
            <Button onClick={handleSave}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Quiz</DialogTitle>
            <DialogDescription>Are you sure you want to delete "{editingQuiz?.title}"?</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteModalOpen(false)}>Cancel</Button>
            <Button variant="destructive" onClick={handleDelete}>Delete</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
