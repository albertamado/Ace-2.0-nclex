import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Message } from '@/api/entities';
import { Course } from '@/api/entities';
import { Enrollment } from '@/api/entities';
import { Notification } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Send, MessageSquare } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { getUserRole } from '../components/utils/getUserRole';
import LoadingScreen from '../components/shared/LoadingScreen';

export default function Messages() {
  const [currentUser, setCurrentUser] = useState(null);
  const [messages, setMessages] = useState([]);
  const [allUsers, setAllUsers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [enrollments, setEnrollments] = useState([]);
  const [isComposeOpen, setIsComposeOpen] = useState(false);
  const [newMessage, setNewMessage] = useState({
    subject: '',
    content: '',
    course_id: '',
    recipient_ids: [],
    is_private: true
  });
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const user = await User.me();
      setCurrentUser(user);

      const userRole = getUserRole(user);

      const allUsersData = await User.list();

      const formattedUsers = allUsersData
        .filter(u => u.id !== user.id)
        .map(u => ({
          id: u.id,
          name: u.full_name || u.email,
          email: u.email,
          role: getUserRole(u),
        }));

      setAllUsers(formattedUsers);

      const allCourses = await Course.list();
      const allEnrollments = await Enrollment.list();
      setCourses(allCourses);
      setEnrollments(allEnrollments);

      let userMessages = [];
      if (userRole === 'admin' || userRole === 'teacher') {
        userMessages = await Message.list('-created_date');
      } else {
        const sent = await Message.filter({ sender_id: user.id }, '-created_date');
        const receivedAll = await Message.list('-created_date');
        const receivedFiltered = receivedAll.filter(m =>
          m.recipient_ids && m.recipient_ids.includes(user.id)
        );
        
        const combinedMessages = [...sent, ...receivedFiltered];
        const uniqueMessages = Array.from(new Map(combinedMessages.map(msg => [msg.id, msg])).values());

        userMessages = uniqueMessages.sort((a, b) =>
          new Date(b.created_date) - new Date(a.created_date)
        );
      }

      setMessages(userMessages);

    } catch (error) {
      console.error("Error loading messages:", error);
    }
    setLoading(false);
  };

  const getRecipientOptions = () => {
    if (!currentUser) return [];
    
    const userRole = getUserRole(currentUser);
    
    if (userRole === 'student') {
      return allUsers.filter(u => {
        return (u.role === 'admin' || u.role === 'teacher');
      });
    } else if (userRole === 'teacher' || userRole === 'admin') {
      if (newMessage.course_id) {
        const courseEnrollments = enrollments.filter(e => e.course_id === newMessage.course_id);
        const enrolledStudentIds = new Set(courseEnrollments.map(e => e.student_id));
        
        return allUsers.filter(u => {
          return enrolledStudentIds.has(u.id) || u.role === 'admin' || u.role === 'teacher';
        });
      }
      return allUsers;
    }
    
    return [];
  };

  const handleSendMessage = async () => {
    if (!newMessage.subject || !newMessage.content || !newMessage.recipient_ids || newMessage.recipient_ids.length === 0) {
      alert("Please fill in all required fields and select at least one recipient");
      return;
    }

    try {
      const messageData = {
        ...newMessage,
        sender_id: currentUser.id,
        read_by: []
      };

      await Message.create(messageData);

      await Promise.all(newMessage.recipient_ids.map(recipientId => 
        Notification.create({
          user_id: recipientId,
          title: 'New Message',
          message: `${currentUser.full_name} sent you a message: ${newMessage.subject}`,
          notification_type: 'message',
          related_entity_type: 'message',
          link_url: '/Messages'
        })
      ));

      await loadData();
      setIsComposeOpen(false);
      setNewMessage({
        subject: '',
        content: '',
        course_id: '',
        recipient_ids: [],
        is_private: true
      });
    } catch (error) {
      console.error("Error sending message:", error);
      alert("Failed to send message. Please try again.");
    }
  };

  const markAsRead = async (message) => {
    if (!message.read_by || !message.read_by.includes(currentUser.id)) {
      try {
        await Message.update(message.id, {
          read_by: [...(message.read_by || []), currentUser.id]
        });
        await loadData();
      } catch (error) {
        console.error("Error marking as read:", error);
      }
    }
  };

  const getSenderName = (senderId) => {
    if (currentUser && senderId === currentUser.id) {
        return currentUser.full_name || 'You';
    }
    const sender = allUsers.find(u => u.id === senderId);
    return sender?.name || 'Unknown';
  };

  const toggleRecipient = (userId) => {
    setNewMessage(prev => {
      const currentIds = prev.recipient_ids || [];
      const newIds = currentIds.includes(userId)
        ? currentIds.filter(id => id !== userId)
        : [...currentIds, userId];
      return { ...prev, recipient_ids: newIds };
    });
  };

  const recipients = getRecipientOptions();

  if (loading) {
    return <LoadingScreen message="Loading messages..." />;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Messages</h1>
          <Button onClick={() => setIsComposeOpen(true)}>
            <Send className="w-4 h-4 mr-2" />
            Compose
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-1 bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-4 border-b">
              <h2 className="font-semibold text-gray-900">Inbox</h2>
            </div>
            <div className="divide-y max-h-[600px] overflow-y-auto">
              {messages.length > 0 ? (
                messages.map(message => {
                  const isUnread = !message.read_by || !message.read_by.includes(currentUser.id);
                  const isSender = message.sender_id === currentUser.id;
                  
                  return (
                    <button
                      key={message.id}
                      onClick={() => {
                        setSelectedMessage(message);
                        if (!isSender) markAsRead(message);
                      }}
                      className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                        isUnread && !isSender ? 'bg-blue-50' : ''
                      } ${selectedMessage?.id === message.id ? 'border-l-4 border-blue-500' : ''}`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1 min-w-0">
                          <p className={`text-sm truncate ${isUnread && !isSender ? 'font-semibold' : ''}`}>
                            {isSender ? `To: ${message.recipient_ids?.map(id => getSenderName(id)).join(', ')}` : getSenderName(message.sender_id)}
                          </p>
                          <p className={`text-sm text-gray-900 truncate mt-1 ${isUnread && !isSender ? 'font-semibold' : ''}`}>
                            {message.subject}
                          </p>
                          <p className="text-xs text-gray-500 truncate mt-1">{message.content}</p>
                        </div>
                        {isUnread && !isSender && (
                          <div className="ml-2 w-2 h-2 bg-blue-500 rounded-full"></div>
                        )}
                      </div>
                      <p className="text-xs text-gray-400 mt-2">
                        {new Date(message.created_date).toLocaleDateString()}
                      </p>
                    </button>
                  );
                })
              ) : (
                <div className="p-8 text-center text-gray-500">
                  <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-30" />
                  <p>No messages yet</p>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            {selectedMessage ? (
              <div>
                <div className="border-b pb-4 mb-4">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2 break-words">{selectedMessage.subject}</h2>
                  <div className="flex items-center justify-between text-sm text-gray-600 flex-wrap gap-2">
                    <span>From: {getSenderName(selectedMessage.sender_id)}</span>
                    <span>{new Date(selectedMessage.created_date).toLocaleString()}</span>
                  </div>
                  {selectedMessage.recipient_ids && selectedMessage.recipient_ids.length > 1 && (
                    <div className="mt-2 text-sm text-gray-600">
                      To: {selectedMessage.recipient_ids.map(id => getSenderName(id)).join(', ')}
                    </div>
                  )}
                </div>
                <div className="prose max-w-none">
                  <p className="text-gray-700 whitespace-pre-wrap break-words">{selectedMessage.content}</p>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-center text-gray-500">
                <div>
                  <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-30" />
                  <p>Select a message to read</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <Dialog open={isComposeOpen} onOpenChange={setIsComposeOpen}>
        <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Compose Message</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4">
            {(getUserRole(currentUser) === 'teacher' || getUserRole(currentUser) === 'admin') && (
              <div>
                <Label className="text-sm font-medium mb-2 block">Filter by Course (Optional)</Label>
                <Select
                  value={newMessage.course_id || ''}
                  onValueChange={(value) => setNewMessage({...newMessage, course_id: value, recipient_ids: []})}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="All Users" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>All Users</SelectItem>
                    {courses.map(course => (
                      <SelectItem key={course.id} value={course.id}>{course.title}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div>
              <Label className="text-sm font-medium mb-2 block">
                Recipients <span className="text-red-500">*</span>
                {newMessage.recipient_ids && newMessage.recipient_ids.length > 0 && (
                  <span className="ml-2 text-gray-500">({newMessage.recipient_ids.length} selected)</span>
                )}
              </Label>
              
              <div className="border rounded-lg p-4 max-h-64 overflow-y-auto space-y-2">
                {(getUserRole(currentUser) === 'teacher' || getUserRole(currentUser) === 'admin') && recipients.length > 0 && (
                  <div className="flex items-center space-x-2 mb-3 pb-2 border-b">
                    <Checkbox
                      id="select-all"
                      checked={newMessage.recipient_ids && newMessage.recipient_ids.length === recipients.length}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setNewMessage({
                            ...newMessage,
                            recipient_ids: recipients.map(u => u.id)
                          });
                        } else {
                          setNewMessage({...newMessage, recipient_ids: []});
                        }
                      }}
                    />
                    <label htmlFor="select-all" className="text-sm font-medium cursor-pointer">
                      Select All ({recipients.length} users)
                    </label>
                  </div>
                )}
                
                {recipients.length > 0 ? (
                  recipients.map(user => (
                    <div key={user.id} className="flex items-center space-x-2 py-1">
                      <Checkbox
                        id={`user-${user.id}`}
                        checked={newMessage.recipient_ids && newMessage.recipient_ids.includes(user.id)}
                        onCheckedChange={() => toggleRecipient(user.id)}
                      />
                      <label htmlFor={`user-${user.id}`} className="text-sm cursor-pointer flex-1">
                        <span className="font-medium">{user.name}</span>
                        <span className="text-gray-500 ml-2">({user.role})</span>
                        <span className="text-gray-400 ml-2 text-xs">{user.email}</span>
                      </label>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-gray-500 text-center py-4">
                    {getUserRole(currentUser) === 'student' 
                      ? 'No teachers or admins available to message' 
                      : 'No users available to message'}
                  </p>
                )}
              </div>
            </div>

            <div>
              <Label className="text-sm font-medium mb-2 block">Subject <span className="text-red-500">*</span></Label>
              <Input
                placeholder="Enter message subject"
                value={newMessage.subject}
                onChange={(e) => setNewMessage({...newMessage, subject: e.target.value})}
              />
            </div>
            
            <div>
              <Label className="text-sm font-medium mb-2 block">Message <span className="text-red-500">*</span></Label>
              <Textarea
                placeholder="Type your message here..."
                value={newMessage.content}
                onChange={(e) => setNewMessage({...newMessage, content: e.target.value})}
                className="min-h-[200px]"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsComposeOpen(false);
              setNewMessage({
                subject: '',
                content: '',
                course_id: '',
                recipient_ids: [],
                is_private: true
              });
            }}>Cancel</Button>
            <Button 
              onClick={handleSendMessage}
              disabled={!newMessage.subject || !newMessage.content || !newMessage.recipient_ids || newMessage.recipient_ids.length === 0}
            >
              <Send className="w-4 h-4 mr-2" />
              Send Message
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}