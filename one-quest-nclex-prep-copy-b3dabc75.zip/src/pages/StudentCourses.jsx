
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { BookOpen, Lock } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import LoadingScreen from "../components/shared/LoadingScreen";

export default function StudentCourses() {
  const [currentUser, setCurrentUser] = useState(null);
  const [enrollments, setEnrollments] = useState([]);
  const [allPhaseCourses, setAllPhaseCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCourses();
  }, []);

  const loadCourses = async () => {
    try {
      const user = await base44.auth.me();
      setCurrentUser(user);

      const userEnrollments = await base44.entities.Enrollment.filter({ student_id: user.id });
      setEnrollments(userEnrollments);

      // Get ALL courses from the student's assigned phase
      if (user.assigned_phase) {
        const phaseCourses = await base44.entities.Course.filter({ phase: user.assigned_phase });
        setAllPhaseCourses(phaseCourses);
      }
    } catch (error) {
      console.error("Error loading courses:", error);
    }
    setLoading(false);
  };

  if (loading) {
    return <LoadingScreen message="Loading your courses..." />;
  }

  const enrolledCourseIds = enrollments.map(e => e.course_id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-navy-50 to-slate-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8 border-2 border-navy-100">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-navy-700 to-navy-900 bg-clip-text text-transparent mb-2">
                PHASE 1: ACADEMIC PHASE
              </h1>
              <p className="text-gray-600 text-lg">
                {currentUser?.assigned_phase ? (
                  <>Phase 1 focuses on core nursing foundations and essential medical-surgical concepts, including oxygenation, fluid and electrolyte balance, nutrition, specimen collection, and major body systems such as neurological, cardiovascular, and respiratory. Each topic is organized into concise modules, lecture overviews, and evidence-based references to enhance comprehension, critical thinking, and application of knowledge. <span className="font-semibold text-navy-600">{currentUser.assigned_phase.replace('phase', 'Phase ')}</span></>
                ) : (
                  'All your enrolled courses'
                )}
              </p>
            </div>
          </div>
        </div>

        {currentUser?.assigned_phase && (
          <div className="mb-8 bg-navy-50 border-2 border-navy-200 rounded-xl p-6">
            <div className="flex items-start gap-3">
              <BookOpen className="w-6 h-6 text-navy-600 flex-shrink-0 mt-1" />
              <div>
                <h3 className="font-semibold text-navy-900 mb-1">Phase-Based Learning</h3>
                <p className="text-sm text-navy-800">
                  You're viewing courses for {currentUser.assigned_phase.replace('phase', 'Phase ')}. 
                  Locked courses require enrollment from your instructor.
                </p>
              </div>
            </div>
          </div>
        )}

        {allPhaseCourses.length === 0 ? (
          <div className="text-center py-16 bg-white rounded-2xl shadow-lg border-2 border-gray-100">
            <BookOpen className="w-20 h-20 text-gray-300 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-gray-900 mb-3">No Courses Yet</h3>
            <p className="text-gray-600 max-w-md mx-auto">
              {currentUser?.assigned_phase 
                ? `No courses available for ${currentUser.assigned_phase.replace('phase', 'Phase ')} yet.`
                : 'You haven\'t been enrolled in any courses yet.'
              }
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allPhaseCourses.map((course) => {
              const isEnrolled = enrolledCourseIds.includes(course.id);
              const enrollment = enrollments.find(e => e.course_id === course.id);
              const progress = enrollment?.progress_percentage || 0;

              return (
                <div key={course.id} className="relative">
                  {isEnrolled ? (
                    <Link to={createPageUrl(`StudentCourse?id=${course.id}`)}>
                      <div className="group bg-white rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden border-2 border-transparent hover:border-navy-200 h-full">
                        {course.cover_photo_url && (
                          <div className="h-48 overflow-hidden">
                            <img
                              src={course.cover_photo_url}
                              alt={course.title}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                          </div>
                        )}
                        
                        <div className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <h3 className="text-xl font-bold text-gray-900 group-hover:text-navy-600 transition-colors line-clamp-2">
                              {course.title}
                            </h3>
                            <BookOpen className="w-6 h-6 text-navy-600 flex-shrink-0" />
                          </div>
                          
                          <p className="text-gray-600 text-sm mb-4 line-clamp-2">{course.description}</p>
                          
                          <div className="space-y-3">
                            <div>
                              <div className="flex justify-between text-sm mb-2">
                                <span className="text-gray-600">Progress</span>
                                <span className="font-bold text-navy-600">{progress}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-2.5">
                                <div
                                  className="bg-gradient-to-r from-navy-600 to-navy-800 h-2.5 rounded-full transition-all duration-500"
                                  style={{ width: `${progress}%` }}
                                ></div>
                              </div>
                            </div>

                            <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                              <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                                progress === 100 
                                  ? 'bg-green-100 text-green-700'
                                  : progress > 0 
                                  ? 'bg-yellow-100 text-yellow-700'
                                  : 'bg-gray-100 text-gray-700'
                              }`}>
                                {progress === 100 ? 'Completed' : progress > 0 ? 'In Progress' : 'Not Started'}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ) : (
                    <div className="bg-white rounded-2xl shadow-lg overflow-hidden border-2 border-gray-200 h-full opacity-60 grayscale cursor-not-allowed">
                      <div className="relative">
                        {course.cover_photo_url && (
                          <div className="h-48 overflow-hidden">
                            <img
                              src={course.cover_photo_url}
                              alt={course.title}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gray-900 bg-opacity-60 flex items-center justify-center">
                          <div className="text-center">
                            <Lock className="w-12 h-12 text-white mx-auto mb-2" />
                            <p className="text-white font-semibold">Locked</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-6">
                        <h3 className="text-xl font-bold text-gray-700 mb-2 line-clamp-2">
                          {course.title}
                        </h3>
                        <p className="text-gray-500 text-sm mb-4 line-clamp-2">{course.description}</p>
                        <p className="text-sm text-gray-500 italic">
                          Contact your instructor to enroll in this course
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
