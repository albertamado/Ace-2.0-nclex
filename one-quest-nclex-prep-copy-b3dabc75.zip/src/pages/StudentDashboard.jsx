
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Enrollment } from "@/api/entities";
import { Course } from "@/api/entities";
import { QuizAttempt } from "@/api/entities";
import { StudentProgress } from "@/api/entities";
import { BookOpen, Clock, Trophy, PlayCircle, FileText, TrendingUp, Calendar, Target, ArrowRight } from "lucide-react";
import { getUserRole } from "../components/utils/getUserRole";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import LoadingScreen from "../components/shared/LoadingScreen";
import { motion } from "framer-motion"; // Import motion for animations

export default function StudentDashboard() {
  const [currentUser, setCurrentUser] = useState(null);
  const [enrollments, setEnrollments] = useState([]);
  const [courses, setCourses] = useState([]);
  const [recentProgress, setRecentProgress] = useState([]);
  const [stats, setStats] = useState({
    totalCourses: 0,
    completedQuizzes: 0,
    averageScore: 0,
    hoursWatched: 0,
    coursesCompleted: 0,
    quizzesCompleted: 0,
    quizzesPassed: 0
  });
  const [loading, setLoading] = useState(true);
  const [nclexCountdown, setNclexCountdown] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    loadDashboardData();
    
    // Set NCLEX date to November 18, 2026, at midnight UTC for consistency
    const nclexDate = new Date('2026-11-18T00:00:00Z'); 
    
    const interval = setInterval(() => {
      const now = new Date();
      const difference = nclexDate.getTime() - now.getTime(); // Use getTime() for reliable difference calculation
      
      if (difference > 0) {
        setNclexCountdown({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
          minutes: Math.floor((difference / 1000 / 60) % 60),
          seconds: Math.floor((difference / 1000) % 60)
        });
      } else {
        setNclexCountdown({ days: 0, hours: 0, minutes: 0, seconds: 0 }); // Countdown finished
        clearInterval(interval);
      }
    }, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const loadDashboardData = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);

      const userRole = getUserRole(user);
      if (userRole === 'admin') {
        window.location.href = createPageUrl("AdminDashboard");
        return;
      } else if (userRole === 'teacher') {
        window.location.href = createPageUrl("TeacherDashboard");
        return;
      }

      const userEnrollments = await Enrollment.filter({ student_id: user.id });
      setEnrollments(userEnrollments);

      if (userEnrollments.length > 0) {
        const courseIds = userEnrollments.map(e => e.course_id);
        const enrolledCourses = await Promise.all(
          courseIds.map(async (courseId) => {
            const course = await Course.filter({ id: courseId });
            return course[0];
          })
        );
        setCourses(enrolledCourses.filter(Boolean));
      }

      const progress = await StudentProgress.filter(
        { student_id: user.id }, 
        '-created_date', 
        10
      );
      setRecentProgress(progress);

      const quizAttempts = await QuizAttempt.filter({ student_id: user.id });
      // Filter for completed quiz attempts only
      const completedQuizAttempts = quizAttempts.filter(a => a.status === 'completed');
      
      // Count unique quizzes that have at least one completed attempt
      const uniqueCompletedQuizzesCount = [...new Set(completedQuizAttempts.map(a => a.quiz_id))].length;
      
      // Count total passed quiz attempts (score >= 75)
      const quizzesPassedCount = completedQuizAttempts.filter(a => a.score >= 75).length;
      
      // Calculate average score across all completed attempts
      const averageScore = completedQuizAttempts.length > 0 
        ? completedQuizAttempts.reduce((sum, a) => sum + a.score, 0) / completedQuizAttempts.length
        : 0;
      
      const totalHours = progress
        .filter(p => p.time_spent_minutes)
        .reduce((sum, p) => sum + p.time_spent_minutes, 0) / 60;
      
      const completedCourses = userEnrollments.filter(e => e.progress_percentage >= 100).length;

      setStats({
        totalCourses: userEnrollments.length,
        completedQuizzes: uniqueCompletedQuizzesCount, // Unique quizzes completed
        averageScore: Math.round(averageScore),
        hoursWatched: Math.round(totalHours * 10) / 10,
        coursesCompleted: completedCourses,
        quizzesCompleted: completedQuizAttempts.length, // Total number of completed attempts
        quizzesPassed: quizzesPassedCount
      });

    } catch (error) {
      console.error("Error loading dashboard data:", error);
      // In a real application, you might want a more user-friendly error display
      // or redirect to an error page.
      window.location.href = createPageUrl("LandingPage");
    }
    setLoading(false);
  };

  if (loading) {
    return <LoadingScreen message="Loading dashboard..." />;
  }

  // Calculate success rate based on total completed attempts vs. passed attempts
  const successRate = stats.quizzesCompleted > 0 
    ? Math.round((stats.quizzesPassed / stats.quizzesCompleted) * 100) 
    : 0;

  const currentHour = new Date().getHours();
  const greeting = currentHour < 12 ? "Good morning" : currentHour < 18 ? "Good afternoon" : "Good evening";

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-navy-50 to-blue-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header with Animation */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative bg-gradient-to-r from-navy-700 via-navy-800 to-navy-900 rounded-3xl shadow-2xl text-white mb-8 p-8 overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <div className="absolute inset-0" style={{
              backgroundImage: 'radial-gradient(circle, white 1px, transparent 1px)',
              backgroundSize: '40px 40px'
            }}></div>
          </div>

          {/* Floating Shapes */}
          <div className="absolute top-4 right-4 w-32 h-32 bg-blue-500 rounded-full mix-blend-overlay filter blur-xl opacity-30 animate-pulse"></div>
          <div className="absolute bottom-4 left-4 w-24 h-24 bg-cyan-400 rounded-full mix-blend-overlay filter blur-xl opacity-30 animate-pulse animation-delay-2000"></div>

          <div className="relative flex flex-col md:flex-row md:items-center justify-between">
            <div>
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 }}
              >
                <h1 className="text-4xl lg:text-5xl font-bold mb-3 flex items-center gap-3">
                  {greeting}, {currentUser?.full_name?.split(' ')[0] || 'Student'}! 
                  <motion.span
                    animate={{ rotate: [0, 14, -8, 14, 0] }}
                    transition={{ duration: 0.5, delay: 0.5 }}
                  >
                    👋
                  </motion.span>
                </h1>
                <p className="text-navy-100 text-lg lg:text-xl flex items-center gap-2">
                  <Clock className="w-5 h-5" />
                  NCLEX EXAM: NOVEMBER 18, 2026 - {nclexCountdown.days} DAYS LEFT 
                  <motion.span
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  >
                    🚀
                  </motion.span>
                </p>
              </motion.div>
            </div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-4 md:mt-0"
            >
              <div className="bg-white/10 backdrop-blur-md rounded-2xl px-6 py-4 border border-white/20">
                <p className="text-navy-100 text-sm mb-1">Overall Progress</p>
                <div className="flex items-end gap-2">
                  <span className="text-3xl font-bold">{Math.round((stats.coursesCompleted / stats.totalCourses) * 100) || 0}%</span>
                  <TrendingUp className="w-6 h-6 text-green-400 mb-1" />
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>

        {/* NCLEX Countdown - Enhanced */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-3xl shadow-2xl p-8 mb-8 border-2 border-navy-100 overflow-hidden relative"
        >
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-navy-100 to-transparent rounded-full -mr-32 -mt-32 opacity-50"></div>
          
          <div className="relative">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-navy-600 to-blue-600 rounded-xl flex items-center justify-center">
                <Target className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-3xl font-bold bg-gradient-to-r from-navy-700 to-navy-900 bg-clip-text text-transparent">
                NCLEX Exam Countdown
              </h2>
            </div>
            
            <div className="grid grid-cols-4 gap-4">
              {[
                { value: nclexCountdown.days, label: 'Days', gradient: 'from-navy-600 to-navy-700' },
                { value: nclexCountdown.hours, label: 'Hours', gradient: 'from-navy-700 to-navy-800' },
                { value: nclexCountdown.minutes, label: 'Minutes', gradient: 'from-navy-800 to-slate-700' },
                { value: nclexCountdown.seconds, label: 'Seconds', gradient: 'from-slate-700 to-slate-800' }
              ].map((item, index) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.3 + index * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  className={`bg-gradient-to-br ${item.gradient} rounded-2xl p-6 shadow-lg transform transition-all duration-300 hover:shadow-xl`}
                >
                  <motion.div
                    key={item.value}
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                    transition={{ duration: 0.3 }}
                    className="text-4xl lg:text-5xl font-bold text-white text-center mb-2"
                  >
                    {item.value.toString().padStart(2, '0')}
                  </motion.div>
                  <div className="text-white/90 text-sm text-center font-medium">{item.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Stats Overview - Enhanced */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {[
            { 
              title: 'Courses Completed',
              value: `${stats.coursesCompleted}/${stats.totalCourses}`,
              icon: BookOpen,
              gradient: 'from-navy-500 to-blue-600',
              bgGradient: 'from-navy-50 to-blue-50',
              iconBg: 'bg-navy-100',
              iconColor: 'text-navy-600'
            },
            { 
              title: 'Quizzes Completed',
              value: stats.completedQuizzes,
              icon: FileText,
              gradient: 'from-green-500 to-emerald-600',
              bgGradient: 'from-green-50 to-emerald-50',
              iconBg: 'bg-green-100',
              iconColor: 'text-green-600'
            },
            { 
              title: 'Average Score',
              value: `${stats.averageScore}%`,
              icon: Trophy,
              gradient: 'from-yellow-500 to-orange-600',
              bgGradient: 'from-yellow-50 to-orange-50',
              iconBg: 'bg-yellow-100',
              iconColor: 'text-yellow-600'
            },
            { 
              title: 'Success Rate',
              value: `${successRate}%`,
              icon: Target,
              gradient: 'from-purple-500 to-pink-600',
              bgGradient: 'from-purple-50 to-pink-50',
              iconBg: 'bg-purple-100',
              iconColor: 'text-purple-600'
            }
          ].map((stat, index) => (
            <motion.div
              key={stat.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + index * 0.1 }}
              whileHover={{ y: -8, transition: { duration: 0.3 } }}
              className={`relative bg-gradient-to-br ${stat.bgGradient} rounded-3xl shadow-lg hover:shadow-2xl border-2 border-white p-6 overflow-hidden group cursor-pointer transition-all duration-300`}
            >
              <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${stat.gradient} opacity-5 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500`}></div>
              
              <div className="relative flex items-center justify-between mb-4">
                <motion.div
                  whileHover={{ rotate: 360, scale: 1.1 }}
                  transition={{ duration: 0.6 }}
                  className={`w-16 h-16 ${stat.iconBg} rounded-2xl flex items-center justify-center shadow-md`}
                >
                  <stat.icon className={`w-8 h-8 ${stat.iconColor}`} />
                </motion.div>
                <div className="text-right">
                  <motion.div
                    key={stat.value}
                    initial={{ scale: 1.2, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className={`text-4xl font-bold bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent`}
                  >
                    {stat.value}
                  </motion.div>
                </div>
              </div>
              
              <div className="relative">
                <p className="text-sm font-semibold text-gray-700 mb-3">{stat.title}</p>
                <div className="w-full h-2 bg-white/50 rounded-full overflow-hidden">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: '100%' }}
                    transition={{ duration: 1, delay: 0.5 + index * 0.1 }}
                    className={`h-full bg-gradient-to-r ${stat.gradient} rounded-full`}
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Courses Section - Enhanced */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="bg-white rounded-3xl shadow-2xl border-2 border-gray-100 overflow-hidden"
        >
          <div className="p-8 bg-gradient-to-r from-navy-50 via-blue-50 to-navy-50 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-gradient-to-br from-navy-600 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                  <BookOpen className="w-7 h-7 text-white" />
                </div>
                <h2 className="text-3xl font-bold bg-gradient-to-r from-navy-700 to-navy-900 bg-clip-text text-transparent">
                  My Courses
                </h2>
              </div>
              <Link to={createPageUrl("StudentCourses")}>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-3 bg-gradient-to-r from-navy-600 to-navy-800 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300 flex items-center gap-2"
                >
                  View All
                  <ArrowRight className="w-5 h-5" />
                </motion.button>
              </Link>
            </div>
          </div>
          
          <div className="p-8">
            {courses.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {courses.map((course, index) => {
                  const enrollment = enrollments.find(e => e.course_id === course.id);
                  const progress = enrollment?.progress_percentage || 0;
                  
                  return (
                    <motion.div
                      key={course.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.9 + index * 0.1 }}
                      whileHover={{ y: -8, transition: { duration: 0.3 } }}
                    >
                      <Link to={createPageUrl(`StudentCourse?id=${course.id}`)}>
                        <div className="group relative bg-gradient-to-br from-white to-navy-50 rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 border-2 border-navy-100 hover:border-navy-300 overflow-hidden">
                          {/* Decorative gradient */}
                          <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-navy-600 to-blue-600 opacity-5 rounded-full -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-500"></div>
                          
                          <div className="relative">
                            <div className="flex items-start gap-3 mb-4">
                              <div className="w-12 h-12 bg-gradient-to-br from-navy-600 to-blue-600 rounded-xl flex items-center justify-center shadow-md flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                                <BookOpen className="w-6 h-6 text-white" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <h3 className="text-xl font-bold text-gray-900 group-hover:text-navy-600 transition-colors mb-2 line-clamp-2">
                                  {course.title}
                                </h3>
                                <p className="text-gray-600 text-sm line-clamp-2">{course.description}</p>
                              </div>
                            </div>
                            
                            <div className="space-y-3">
                              <div className="flex justify-between text-sm items-center">
                                <span className="text-gray-600 font-medium">Progress</span>
                                <span className="font-bold text-navy-600 text-lg">{progress}%</span>
                              </div>
                              <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                                <motion.div
                                  initial={{ width: 0 }}
                                  animate={{ width: `${progress}%` }}
                                  transition={{ duration: 1, delay: 1 + index * 0.1 }}
                                  className="bg-gradient-to-r from-navy-600 to-blue-600 h-3 rounded-full relative overflow-hidden"
                                >
                                  <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                                </motion.div>
                              </div>
                              
                              <div className="flex items-center justify-between pt-3 border-t border-gray-200">
                                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                                  progress === 100 
                                    ? 'bg-green-100 text-green-700'
                                    : progress > 0 
                                    ? 'bg-blue-100 text-blue-700'
                                    : 'bg-gray-100 text-gray-700'
                                }`}>
                                  {progress === 100 ? '✓ Completed' : progress > 0 ? '📚 In Progress' : '🎯 Not Started'}
                                </span>
                                <ArrowRight className="w-5 h-5 text-navy-600 group-hover:translate-x-2 transition-transform" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </Link>
                    </motion.div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-16">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", duration: 0.6 }}
                  className="w-24 h-24 bg-gradient-to-br from-navy-100 to-blue-100 rounded-full flex items-center justify-center mx-auto mb-6"
                >
                  <BookOpen className="w-12 h-12 text-navy-600" />
                </motion.div>
                <h3 className="text-2xl font-bold text-gray-900 mb-3">No Courses Yet</h3>
                <p className="text-gray-600 mb-6">Start your learning journey by enrolling in a course</p>
                <Link to={createPageUrl("Programs")}>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-8 py-4 bg-gradient-to-r from-navy-600 to-navy-800 text-white rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
                  >
                    Explore Courses
                  </motion.button>
                </Link>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
