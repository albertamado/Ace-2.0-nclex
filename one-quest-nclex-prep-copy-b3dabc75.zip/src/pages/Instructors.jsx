import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { InstructorProfile } from '@/api/entities';
import { Course } from '@/api/entities';
import { getUserRole } from '../components/utils/getUserRole';
import { Mail, BookOpen, Award, Users, Star, GraduationCap, CheckCircle } from 'lucide-react';

export default function Instructors() {
  const [currentUser, setCurrentUser] = useState(null);
  const [instructors, setInstructors] = useState([]);
  const [instructorProfiles, setInstructorProfiles] = useState([]);
  const [instructorCourses, setInstructorCourses] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkUser = async () => {
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (error) {
        setCurrentUser(null);
      }
    };
    checkUser();
  }, []);

  useEffect(() => {
    loadInstructors();
  }, []);

  const loadInstructors = async () => {
    setLoading(true);
    try {
      // Load user-based instructors
      const allUsers = await User.list();
      const teachers = allUsers.filter(u => getUserRole(u) === 'teacher');
      setInstructors(teachers);

      // Load instructor profiles (can exist without user accounts)
      const profiles = await InstructorProfile.filter({ is_active: true });
      setInstructorProfiles(profiles);

      // Load courses for all instructors
      const allCourses = await Course.list();
      const coursesMap = {};
      
      // Map courses for user-based instructors
      teachers.forEach(teacher => {
        coursesMap[teacher.id] = allCourses.filter(c => c.instructor_id === teacher.id);
      });

      setInstructorCourses(coursesMap);
    } catch (error) {
      console.error("Error loading instructors:", error);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  // Combine user-based instructors and profiles
  const allInstructorData = [
    ...instructors.map(instructor => ({
      id: instructor.id,
      full_name: instructor.full_name,
      email: instructor.email,
      phone: instructor.phone,
      bio: instructor.bio || 'Experienced healthcare educator dedicated to helping students achieve their NCLEX goals.',
      profile_photo_url: instructor.profile_photo_url,
      specialization: instructor.specialization || 'NCLEX Preparation',
      years_of_experience: instructor.years_of_experience || 10,
      education: instructor.education || 'MSN, RN',
      achievements: instructor.achievements || [],
      courses: instructorCourses[instructor.id] || [],
      hasUserAccount: true
    })),
    ...instructorProfiles.filter(profile => !profile.user_id).map(profile => ({
      id: profile.id,
      full_name: profile.full_name,
      email: profile.email,
      phone: profile.phone,
      bio: profile.bio,
      profile_photo_url: profile.profile_photo_url,
      specialization: profile.specialization,
      years_of_experience: profile.years_of_experience,
      education: profile.education,
      achievements: profile.achievements || [],
      courses: [],
      hasUserAccount: false
    }))
  ];

  return (
    <div className="min-h-screen bg-white pt-20"> 
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Meet Our Expert Instructors</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Learn from experienced healthcare professionals dedicated to your NCLEX success
          </p>
        </div>

        {allInstructorData.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {allInstructorData.map((instructor) => (
              <div key={instructor.id} className="bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                {/* Profile Image */}
                <div className="relative h-64 bg-gradient-to-br from-blue-500 to-teal-500">
                  {instructor.profile_photo_url ? (
                    <img 
                      src={instructor.profile_photo_url} 
                      alt={instructor.full_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center">
                        <span className="text-5xl font-bold text-blue-600">
                          {instructor.full_name?.[0]?.toUpperCase() || 'T'}
                        </span>
                      </div>
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-6">
                    <h3 className="text-2xl font-bold text-white">{instructor.full_name}</h3>
                    {instructor.education && (
                      <p className="text-white/90 text-sm">{instructor.education}</p>
                    )}
                  </div>
                </div>

                {/* Instructor Info */}
                <div className="p-6">
                  {/* Specialization & Experience */}
                  <div className="flex items-center justify-between mb-4 pb-4 border-b border-gray-100">
                    <div className="flex items-center text-sm">
                      <GraduationCap className="w-5 h-5 mr-2 text-blue-500" />
                      <span className="font-medium text-gray-700">{instructor.specialization}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <Award className="w-5 h-5 mr-2 text-green-500" />
                      <span className="font-medium text-gray-700">{instructor.years_of_experience}+ years</span>
                    </div>
                  </div>

                  {/* Bio */}
                  <div className="mb-4">
                    <p className="text-gray-600 text-sm leading-relaxed line-clamp-3">
                      {instructor.bio}
                    </p>
                  </div>

                  {/* Achievements */}
                  {instructor.achievements && instructor.achievements.length > 0 && (
                    <div className="mb-4">
                      <p className="text-xs font-semibold text-gray-500 uppercase mb-2">Achievements</p>
                      <div className="space-y-1">
                        {instructor.achievements.slice(0, 2).map((achievement, idx) => (
                          <div key={idx} className="flex items-start text-sm text-gray-700">
                            <CheckCircle className="w-4 h-4 mr-2 text-green-500 flex-shrink-0 mt-0.5" />
                            <span className="line-clamp-1">{achievement}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Contact */}
                  {instructor.email && (
                    <a 
                      href={`mailto:${instructor.email}`}
                      className="flex items-center text-blue-600 hover:text-blue-700 text-sm mb-3"
                    >
                      <Mail className="w-4 h-4 mr-2" />
                      {instructor.email}
                    </a>
                  )}

                  {/* Courses Taught */}
                  {instructor.courses && instructor.courses.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <p className="text-xs font-semibold text-gray-500 uppercase">Courses</p>
                        <div className="flex items-center text-sm text-gray-500">
                          <BookOpen className="w-4 h-4 mr-1"/>
                          {instructor.courses.length}
                        </div>
                      </div>
                      <div className="space-y-1">
                        {instructor.courses.slice(0, 3).map(course => (
                          <p key={course.id} className="text-sm text-gray-700 line-clamp-1">• {course.title}</p>
                        ))}
                        {instructor.courses.length > 3 && (
                          <p className="text-sm text-gray-500">+ {instructor.courses.length - 3} more</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-2xl">
            <Award className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Instructors Yet</h3>
            <p className="text-gray-500">Check back soon for our expert instructors</p>
          </div>
        )}
      </div>
    </div>
  );
}