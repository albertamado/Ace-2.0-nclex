
import React, { useState, useEffect } from "react";
import { User } from "@/api/entities";
import { Course } from "@/api/entities";
import { Module } from "@/api/entities";
import { Section } from "@/api/entities";
import { Video } from "@/api/entities";
import { Quiz } from "@/api/entities"; // Added Quiz import
import { Enrollment } from "@/api/entities";
import { QuizAttempt } from "@/api/entities";
import { StudentProgress } from "@/api/entities";
import { BookOpen, Users, FileText, TrendingUp, Calendar, Clock, PlayCircle, ChevronRight } from "lucide-react";
import { getUserRole } from "../components/utils/getUserRole";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { motion } from "framer-motion"; // Import motion from framer-motion

export default function TeacherDashboard() {
  const [currentUser, setCurrentUser] = useState(null);
  const [courses, setCourses] = useState([]);
  const [courseDetails, setCourseDetails] = useState({});
  const [enrollments, setEnrollments] = useState([]);
  const [quizAttempts, setQuizAttempts] = useState([]);
  const [recentProgress, setRecentProgress] = useState([]);
  const [progressSummary, setProgressSummary] = useState({});
  const [stats, setStats] = useState({
    totalCourses: 0,
    totalStudents: 0,
    totalLectures: 0,
    totalQuizzes: 0,
    averageScore: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const user = await User.me();
      setCurrentUser(user);

      const userRole = getUserRole(user);
      if (userRole !== 'teacher') {
        if (userRole === 'admin') {
          window.location.href = createPageUrl("AdminDashboard");
          return;
        } else {
          window.location.href = createPageUrl("StudentDashboard");
          return;
        }
      }

      // Load teacher's courses
      const teacherCourses = await Course.filter({ instructor_id: user.id });
      setCourses(teacherCourses);

      // Load detailed information for each course INCLUDING PROGRESS SUMMARY
      const details = {};
      const progressSummaryData = {};
      let totalLectures = 0;
      let totalQuizzes = 0;

      for (const course of teacherCourses) {
        const [modules, sections, videos, quizzes, courseEnrollments, courseProgress] = await Promise.all([
          Module.filter({ course_id: course.id }, 'order_index'),
          Section.filter({ course_id: course.id }, 'order_index'),
          Video.filter({ course_id: course.id }, 'order_index'),
          Quiz.filter({ course_id: course.id }),
          Enrollment.filter({ course_id: course.id }),
          StudentProgress.filter({ course_id: course.id }) // Fetched but not directly used for the summary below, still part of the data fetching.
        ]);

        details[course.id] = {
          modules,
          sections,
          videos,
          quizzes,
          enrollmentCount: courseEnrollments.length
        };

        // Calculate progress summary for this course
        const totalStudents = courseEnrollments.length;
        const completedStudents = courseEnrollments.filter(e => e.progress_percentage >= 100).length;
        const inProgressStudents = courseEnrollments.filter(e => e.progress_percentage > 0 && e.progress_percentage < 100).length;
        const notStartedStudents = courseEnrollments.filter(e => !e.progress_percentage || e.progress_percentage === 0).length;

        progressSummaryData[course.id] = {
          totalStudents,
          completedStudents,
          inProgressStudents,
          notStartedStudents,
          completionRate: totalStudents > 0 ? Math.round((completedStudents / totalStudents) * 100) : 0
        };

        totalLectures += videos.length;
        totalQuizzes += quizzes.length;
      }

      setCourseDetails(details);
      setProgressSummary(progressSummaryData);

      // Load enrollments for all teacher's courses
      const courseIds = teacherCourses.map(c => c.id);
      const allEnrollments = [];
      for (const courseId of courseIds) {
        const courseEnrollments = await Enrollment.filter({ course_id: courseId });
        allEnrollments.push(...courseEnrollments);
      }
      setEnrollments(allEnrollments);

      // Load quiz attempts for teacher's courses
      const allQuizAttempts = await QuizAttempt.list();
      setQuizAttempts(allQuizAttempts);

      // Load recent progress
      const allProgress = [];
      for (const courseId of courseIds) {
        const courseProgress = await StudentProgress.filter(
          { course_id: courseId },
          '-created_date',
          10
        );
        allProgress.push(...courseProgress);
      }
      setRecentProgress(allProgress.slice(0, 10));

      // Calculate stats
      const uniqueStudents = new Set(allEnrollments.map(e => e.student_id));
      const completedQuizzes = allQuizAttempts.filter(a => a.status === 'completed');
      const averageScore = completedQuizzes.length > 0
        ? completedQuizzes.reduce((sum, a) => sum + a.score, 0) / completedQuizzes.length
        : 0;

      setStats({
        totalCourses: teacherCourses.length,
        totalStudents: uniqueStudents.size,
        totalLectures,
        totalQuizzes,
        averageScore: Math.round(averageScore)
      });

    } catch (error) {
      console.error("Error loading dashboard data:", error);
      window.location.href = createPageUrl("LandingPage");
    }
    setLoading(false);
  };

  const statCards = [
    { 
      title: "My Courses", 
      value: stats.totalCourses, 
      icon: BookOpen, 
      gradient: "from-blue-500 to-cyan-500",
      bgGradient: "from-blue-50 to-cyan-50",
      iconBg: "bg-blue-100",
      iconColor: "text-blue-600",
      link: createPageUrl("TeacherCourses")
    },
    { 
      title: "Total Students", 
      value: stats.totalStudents, 
      icon: Users, 
      gradient: "from-green-500 to-emerald-500",
      bgGradient: "from-green-50 to-emerald-50",
      iconBg: "bg-green-100",
      iconColor: "text-green-600",
      link: createPageUrl("TeacherCourses")
    },
    { 
      title: "Total Lectures", 
      value: stats.totalLectures, 
      icon: PlayCircle, 
      gradient: "from-purple-500 to-pink-500",
      bgGradient: "from-purple-50 to-pink-50",
      iconBg: "bg-purple-100",
      iconColor: "text-purple-600",
      link: createPageUrl("TeacherCourses")
    },
    { 
      title: "Total Quizzes", 
      value: stats.totalQuizzes, 
      icon: FileText, 
      gradient: "from-orange-500 to-red-500",
      bgGradient: "from-orange-50 to-red-50",
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      link: createPageUrl("TeacherCourses")
    },
    { 
      title: "Avg Score", 
      value: `${stats.averageScore}%`, 
      icon: TrendingUp, 
      gradient: "from-teal-500 to-cyan-500",
      bgGradient: "from-teal-50 to-cyan-50",
      iconBg: "bg-teal-100",
      iconColor: "text-teal-600",
      link: createPageUrl("StudentPerformance") // Assuming StudentPerformance exists for analytics
    },
  ];

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Section */}
        <div className="bg-gradient-to-r from-blue-600 to-teal-600 rounded-2xl shadow-lg text-white mb-8">
          <div className="p-8">
            <h1 className="text-3xl font-bold mb-2">
              Welcome back, {currentUser?.full_name}! 👨‍🏫
            </h1>
            <p className="text-blue-100 mb-4">
              Manage your courses and track student progress
            </p>
            <div className="flex items-center text-blue-100">
              <Calendar className="w-4 h-4 mr-2" />
              <span className="text-sm">{new Date().toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}</span>
            </div>
          </div>
        </div>

        {/* Stats Overview with Clickable Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-6 mb-8">
          {statCards.map((stat, index) => (
            <Link key={stat.title} to={stat.link}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className={`relative bg-gradient-to-br ${stat.bgGradient} rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 overflow-hidden group cursor-pointer p-6`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-0 group-hover:opacity-10 transition-opacity duration-300`}></div>
                
                <div className="relative">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <p className="text-sm font-semibold text-gray-600 uppercase tracking-wide mb-1">{stat.title}</p>
                      <motion.p
                        key={stat.value} // Key for re-animating value changes
                        initial={{ scale: 1.2, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        className="text-3xl font-bold text-gray-900"
                      >
                        {stat.value}
                      </motion.p>
                    </div>
                    <motion.div
                      whileHover={{ rotate: 360 }}
                      transition={{ duration: 0.6 }}
                      className={`w-12 h-12 ${stat.iconBg} rounded-xl flex items-center justify-center shadow-md`}
                    >
                      <stat.icon className={`w-6 h-6 ${stat.iconColor}`} />
                    </motion.div>
                  </div>
                  
                  <div className="w-full bg-gray-200 rounded-full h-1 overflow-hidden">
                    <motion.div
                      initial={{ width: 0 }}
                      animate={{ width: '100%' }}
                      transition={{ duration: 1, delay: index * 0.1 }}
                      className={`h-full bg-gradient-to-r ${stat.gradient} rounded-full`}
                    />
                  </div>
                </div>

                <div className={`absolute top-0 right-0 w-20 h-20 bg-gradient-to-br ${stat.gradient} opacity-10 rounded-bl-full`}></div>
              </motion.div>
            </Link>
          ))}
        </div>

        {/* Course Progress Summary Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">Course Progress Summary</h2>
          </div>
          <div className="p-6">
            <div className="space-y-6">
              {courses.length > 0 ? (
                courses.map((course) => {
                  const summary = progressSummary[course.id] || {};
                  return (
                    <div key={course.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-semibold text-gray-900">{course.title}</h3>
                          <p className="text-sm text-gray-500">{summary.totalStudents} students enrolled</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-blue-600">{summary.completionRate}%</p>
                          <p className="text-xs text-gray-500">Completion Rate</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                          <p className="text-2xl font-bold text-green-600">{summary.completedStudents || 0}</p>
                          <p className="text-xs text-green-700">Completed</p>
                        </div>
                        <div className="text-center p-3 bg-yellow-50 rounded-lg">
                          <p className="text-2xl font-bold text-yellow-600">{summary.inProgressStudents || 0}</p>
                          <p className="text-xs text-yellow-700">In Progress</p>
                        </div>
                        <div className="text-center p-3 bg-gray-50 rounded-lg">
                          <p className="text-2xl font-bold text-gray-600">{summary.notStartedStudents || 0}</p>
                          <p className="text-xs text-gray-700">Not Started</p>
                        </div>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center py-8">
                  <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No courses assigned yet</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Enhanced Quiz Analytics Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">Quiz Analytics</h2>
            <p className="text-sm text-gray-600 mt-1">Detailed performance metrics for your quizzes</p>
          </div>
          <div className="p-6">
            {courses.length > 0 ? (
              <div className="space-y-6">
                {courses.map((course) => {
                  const details = courseDetails[course.id] || {};
                  const quizzes = details.quizzes || [];
                  
                  if (quizzes.length === 0) return null;
                  
                  return (
                    <div key={course.id} className="border border-gray-200 rounded-lg p-4">
                      <h3 className="font-semibold text-gray-900 mb-4">{course.title}</h3>
                      
                      <div className="space-y-4">
                        {quizzes.map((quiz) => {
                          const attempts = quizAttempts.filter(a => a.quiz_id === quiz.id && a.status === 'completed');
                          const totalAttempts = attempts.length;
                          const avgScore = totalAttempts > 0 
                            ? Math.round(attempts.reduce((sum, a) => sum + a.score, 0) / totalAttempts)
                            : 0;
                          
                          return (
                            <div key={quiz.id} className="bg-gray-50 rounded-lg p-4">
                              <div className="flex justify-between items-start mb-3">
                                <div>
                                  <h4 className="font-medium text-gray-900">{quiz.title}</h4>
                                  <p className="text-sm text-gray-600">{quiz.questions?.length || 0} questions</p>
                                </div>
                                <div className="text-right">
                                  <p className="text-2xl font-bold text-blue-600">{avgScore}%</p>
                                  <p className="text-xs text-gray-500">Avg Score</p>
                                </div>
                              </div>
                              
                              <div className="grid grid-cols-3 gap-3 mb-4">
                                <div className="bg-white rounded p-3 text-center">
                                  <p className="text-lg font-bold text-gray-900">{totalAttempts}</p>
                                  <p className="text-xs text-gray-600">Attempts</p>
                                </div>
                                <div className="bg-white rounded p-3 text-center">
                                  <p className="text-lg font-bold text-green-600">
                                    {totalAttempts > 0 ? Math.round((attempts.filter(a => a.score >= (quiz.passing_score || 60)).length / totalAttempts) * 100) : 0}%
                                  </p>
                                  <p className="text-xs text-gray-600">Pass Rate</p>
                                </div>
                                <div className="bg-white rounded p-3 text-center">
                                  <p className="text-lg font-bold text-gray-900">{new Set(attempts.map(a => a.student_id)).size}</p>
                                  <p className="text-xs text-gray-600">Students</p>
                                </div>
                              </div>
                              
                              {/* Per-Question Analytics */}
                              {quiz.questions && quiz.questions.length > 0 && (
                                <div className="border-t border-gray-200 pt-3 mt-3">
                                  <p className="text-sm font-semibold text-gray-700 mb-2">Question Performance:</p>
                                  <div className="space-y-2">
                                    {quiz.questions.map((question, qIndex) => {
                                      // Calculate percentage of correct answers for this question
                                      const questionAttempts = attempts.filter(a => a.answers && a.answers[qIndex] !== undefined);
                                      const correctCount = questionAttempts.filter(a => {
                                        const answer = a.answers[qIndex];
                                        const correctAnswer = question.correct_answer;
                                        if (Array.isArray(correctAnswer)) {
                                          return JSON.stringify(answer) === JSON.stringify(correctAnswer);
                                        }
                                        return answer === correctAnswer;
                                      }).length;
                                      const correctPercentage = questionAttempts.length > 0 
                                        ? Math.round((correctCount / questionAttempts.length) * 100)
                                        : 0;
                                      
                                      return (
                                        <div key={qIndex} className="flex items-center gap-3 bg-white rounded p-2">
                                          <span className="text-xs font-medium text-gray-600 w-8">Q{qIndex + 1}</span>
                                          <div className="flex-1">
                                            <div className="flex justify-between items-center mb-1">
                                              <span className="text-xs text-gray-700 truncate">{question.question}</span>
                                              <span className={`text-xs font-bold ${correctPercentage >= 70 ? 'text-green-600' : correctPercentage >= 50 ? 'text-yellow-600' : 'text-red-600'}`}>
                                                {correctPercentage}%
                                              </span>
                                            </div>
                                            <div className="w-full bg-gray-200 rounded-full h-1.5">
                                              <div 
                                                className={`h-1.5 rounded-full ${correctPercentage >= 70 ? 'bg-green-500' : correctPercentage >= 50 ? 'bg-yellow-500' : 'bg-red-500'}`}
                                                style={{ width: `${correctPercentage}%` }}
                                              />
                                            </div>
                                            <div className="flex justify-between text-[10px] text-gray-500 mt-1">
                                              <span>✓ {correctCount} correct</span>
                                              <span>✗ {questionAttempts.length - correctCount} wrong</span>
                                            </div>
                                          </div>
                                        </div>
                                      );
                                    })}
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No quiz analytics available</p>
              </div>
            )}
          </div>
        </div>

        {/* My Courses with Details */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 mb-8">
          <div className="p-6 border-b border-gray-100 flex justify-between items-center">
            <h2 className="text-xl font-bold text-gray-900">My Courses & Lectures</h2>
            <Link to={createPageUrl("TeacherCourses")}>
              <button className="text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
                View All <ChevronRight className="w-4 h-4 ml-1" />
              </button>
            </Link>
          </div>
          <div className="p-6">
            {courses.length > 0 ? (
              <Accordion type="single" collapsible className="w-full">
                {courses.map((course) => {
                  const details = courseDetails[course.id] || {};
                  const modules = details.modules || [];
                  const videos = details.videos || [];
                  const quizzes = details.quizzes || [];
                  const enrollmentCount = details.enrollmentCount || 0;

                  return (
                    <AccordionItem key={course.id} value={`course-${course.id}`} className="border-b border-gray-200">
                      <AccordionTrigger className="hover:bg-gray-50 px-4 py-4 rounded-lg">
                        <div className="flex items-center justify-between w-full mr-4">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-teal-500 rounded-lg flex items-center justify-center">
                              <BookOpen className="w-6 h-6 text-white" />
                            </div>
                            <div className="text-left">
                              <h3 className="font-semibold text-gray-900">{course.title}</h3>
                              <p className="text-sm text-gray-500 capitalize">{course.category}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-6 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Users className="w-4 h-4" /> {enrollmentCount}
                            </span>
                            <span className="flex items-center gap-1">
                              <PlayCircle className="w-4 h-4" /> {videos.length}
                            </span>
                            <span className="flex items-center gap-1">
                              <FileText className="w-4 h-4" /> {quizzes.length}
                            </span>
                          </div>
                        </div>
                      </AccordionTrigger>
                      <AccordionContent className="px-4 pb-4">
                        {modules.length > 0 ? (
                          <div className="space-y-4 mt-4">
                            {modules.map((module) => {
                              const moduleVideos = videos.filter(v => v.module_id === module.id);
                              return (
                                <div key={module.id} className="bg-gray-50 rounded-lg p-4">
                                  <h4 className="font-medium text-gray-900 mb-3">{module.title}</h4>
                                  {moduleVideos.length > 0 ? (
                                    <div className="space-y-2">
                                      {moduleVideos.slice(0, 5).map((video) => (
                                        <div key={video.id} className="flex items-center gap-2 text-sm text-gray-700 bg-white p-2 rounded">
                                          <PlayCircle className="w-4 h-4 text-blue-500" />
                                          <span className="flex-1">{video.title}</span>
                                          <span className="text-gray-500 text-xs">{video.duration_minutes} min</span>
                                        </div>
                                      ))}
                                      {moduleVideos.length > 5 && (
                                        <p className="text-sm text-gray-500 pl-6">+ {moduleVideos.length - 5} more lectures</p>
                                      )}
                                    </div>
                                  ) : (
                                    <p className="text-sm text-gray-500">No lectures in this module yet</p>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        ) : videos.length > 0 ? (
                          <div className="space-y-2 mt-4">
                            {videos.slice(0, 5).map((video) => (
                              <div key={video.id} className="flex items-center gap-2 text-sm text-gray-700 bg-gray-50 p-3 rounded">
                                <PlayCircle className="w-4 h-4 text-blue-500" />
                                <span className="flex-1">{video.title}</span>
                                <span className="text-gray-500 text-xs">{video.duration_minutes} min</span>
                              </div>
                            ))}
                            {videos.length > 5 && (
                              <p className="text-sm text-gray-500">+ {videos.length - 5} more lectures</p>
                            )}
                          </div>
                        ) : (
                          <p className="text-sm text-gray-500 mt-4">No lectures in this course yet</p>
                        )}

                        <Link to={createPageUrl(`TeacherCourseDetail?id=${course.id}`)}>
                          <button className="mt-4 text-blue-600 hover:text-blue-700 text-sm font-medium flex items-center">
                            Manage Course <ChevronRight className="w-4 h-4 ml-1" />
                          </button>
                        </Link>
                      </AccordionContent>
                    </AccordionItem>
                  );
                })}
              </Accordion>
            ) : (
              <div className="text-center py-8">
                <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No courses assigned yet</p>
              </div>
            )}
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-xl font-bold text-gray-900">Recent Student Activity</h2>
          </div>
          <div className="p-6">
            {recentProgress.length > 0 ? (
              <div className="space-y-4">
                {recentProgress.map((activity, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-shrink-0">
                      {activity.progress_type.includes('video') ? (
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <PlayCircle className="w-4 h-4 text-blue-600" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <FileText className="w-4 h-4 text-green-600" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">
                        Student {activity.progress_type.replace('_', ' ')}
                      </p>
                      <div className="flex items-center space-x-2 mt-1">
                        <Clock className="w-3 h-3 text-gray-400" />
                        <p className="text-xs text-gray-500">
                          {new Date(activity.created_date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <TrendingUp className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <p className="text-gray-500">No recent activity</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
