
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Clock, CheckCircle, XCircle, AlertTriangle, ChevronLeft, ChevronRight, GripVertical, MessageSquare } from "lucide-react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function QuizTaker({ quiz, student, onComplete, canTakeQuiz, missingVideos, accessInfo }) {
  const [answers, setAnswers] = useState({});
  const [timeRemaining, setTimeRemaining] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [attemptStartTime, setAttemptStartTime] = useState(null);
  const [showResults, setShowResults] = useState(false);
  const [score, setScore] = useState(0);
  const [attempts, setAttempts] = useState([]);
  const [currentAttemptNumber, setCurrentAttemptNumber] = useState(1);
  const [rankingOrders, setRankingOrders] = useState({});
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  useEffect(() => {
    loadAttempts();
    setAttemptStartTime(new Date());
    
    if (quiz.time_limit_minutes) {
      setTimeRemaining(quiz.time_limit_minutes * 60);
    }
  }, [quiz.id, student.id]);

  useEffect(() => {
    if (timeRemaining !== null && timeRemaining > 0 && !showResults) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            clearInterval(timer);
            handleSubmit();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      return () => clearInterval(timer);
    }
  }, [timeRemaining, showResults]);

  const loadAttempts = async () => {
    try {
      const userAttempts = await base44.entities.QuizAttempt.filter({ 
        student_id: student.id, 
        quiz_id: quiz.id 
      });
      setAttempts(userAttempts);
      setCurrentAttemptNumber(userAttempts.length + 1);
      
      const completedAttempts = userAttempts.filter(a => a.status === 'completed');
      if (completedAttempts.length > 0) {
        const lastAttempt = completedAttempts[completedAttempts.length - 1];
        setShowResults(true);
        setScore(lastAttempt.score);
        
        if (lastAttempt.answers) {
          const answersObj = {};
          lastAttempt.answers.forEach((ans, idx) => {
            answersObj[idx] = ans;
          });
          setAnswers(answersObj);
        }
      }
    } catch (error) {
      console.error("Error loading attempts:", error);
    }
  };

  const handleAnswerChange = (questionIndex, answer) => {
    setAnswers(prev => ({
      ...prev,
      [questionIndex]: answer
    }));
  };

  const handleMatrixChange = (questionIndex, rowIndex, columnIndex, checked) => {
    const currentAnswers = answers[questionIndex] || {};
    const rowKey = `${rowIndex}-${columnIndex}`;
    
    setAnswers(prev => ({
      ...prev,
      [questionIndex]: {
        ...currentAnswers,
        [rowKey]: checked
      }
    }));
  };

  const handleRankingReorder = (questionIndex, result) => {
    if (!result.destination) return;

    const question = quiz.questions[questionIndex];
    const items = rankingOrders[questionIndex] || question.options.map((_, idx) => idx);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);

    setRankingOrders(prev => ({
      ...prev,
      [questionIndex]: items
    }));

    setAnswers(prev => ({
      ...prev,
      [questionIndex]: items
    }));
  };

  const handleSubmit = async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      // For the answers array, we store the first answer as a number (for DB compatibility)
      // The actual grading logic uses the answers state object
      const answerArray = quiz.questions.map((question, idx) => {
        const answer = answers[idx];
        
        // Always return a valid number (0 for no answer)
        if (question.question_type === 'multiple_choice') {
          if (typeof answer === 'number') {
            return answer;
          } else if (Array.isArray(answer) && answer.length > 0) {
            return answer[0];
          }
          return 0;
        } else if (question.question_type === 'matrix') {
          // For matrix, return 0 (we'll use full state for grading)
          return 0;
        } else if (question.question_type === 'ranking') {
          // For ranking, return 0 (we'll use full state for grading)
          return 0;
        }
        
        return 0;
      });
      
      let totalScore = 0;
      let earnedPoints = 0;
      
      quiz.questions.forEach((question, idx) => {
        const points = question.points || 1;
        totalScore += points;
        
        const userAnswer = answers[idx];
        
        if (question.question_type === 'multiple_choice') {
          const correctAnswers = Array.isArray(question.correct_answer) ? question.correct_answer : [];
          const userAnswers = Array.isArray(userAnswer) ? userAnswer : (userAnswer !== null && userAnswer !== undefined ? [userAnswer] : []);
          
          if (correctAnswers.length === userAnswers.length &&
              correctAnswers.every(ans => userAnswers.includes(ans))) {
            earnedPoints += points;
          }
        } else if (question.question_type === 'matrix') {
          const matrixCorrect = question.matrix_correct_answers || {};
          const userMatrixAnswers = userAnswer || {};
          
          let allCorrect = true;
          
          for (let key in matrixCorrect) {
            if (matrixCorrect[key] !== !!userMatrixAnswers[key]) {
              allCorrect = false;
              break;
            }
          }
          
          for (let key in userMatrixAnswers) {
            if (userMatrixAnswers[key] && !matrixCorrect[key]) {
                allCorrect = false;
                break;
            }
          }

          if (allCorrect) {
            earnedPoints += points;
          }
        } else if (question.question_type === 'ranking') {
          const correctOrder = question.ranking_correct_order || question.options.map((_, i) => i);
          const userOrder = Array.isArray(userAnswer) ? userAnswer : [];
          
          if (JSON.stringify(correctOrder) === JSON.stringify(userOrder)) {
            earnedPoints += points;
          }
        }
      });
      
      const percentageScore = totalScore > 0 ? Math.round((earnedPoints / totalScore) * 100) : 0;
      const timeTaken = attemptStartTime ? Math.round((new Date() - attemptStartTime) / 60000) : 0;
      
      const attemptData = {
        student_id: student.id,
        quiz_id: quiz.id,
        answers: answerArray,
        score: percentageScore,
        time_taken_minutes: timeTaken,
        attempt_number: currentAttemptNumber,
        status: 'completed',
        started_at: attemptStartTime?.toISOString() || new Date().toISOString(),
        completed_at: new Date().toISOString()
      };
      
      await base44.entities.QuizAttempt.create(attemptData);
      
      const passed = !quiz.passing_score || percentageScore >= quiz.passing_score;
      
      if (passed) {
        const progressData = {
          student_id: student.id,
          course_id: quiz.course_id,
          quiz_id: quiz.id,
          progress_type: 'quiz_completed',
          completion_percentage: 100,
          time_spent_minutes: timeTaken,
          completed_at: new Date().toISOString()
        };
        await base44.entities.StudentProgress.create(progressData);
      }
      
      setScore(percentageScore);
      setShowResults(true);
      
      await loadAttempts();
      
      if (onComplete) {
        onComplete();
      }
      
    } catch (error) {
      console.error("Error submitting quiz:", error);
      alert("Failed to submit quiz. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleTryAgain = async () => {
    // Reset all states
    setShowResults(false);
    setAnswers({});
    setRankingOrders({});
    setCurrentQuestionIndex(0);
    setScore(0);
    setAttemptStartTime(new Date());
    
    // Reset timer
    if (quiz.time_limit_minutes) {
      setTimeRemaining(quiz.time_limit_minutes * 60);
    }
    
    // Reload attempts to get the updated count for the new attempt
    try {
      const userAttempts = await base44.entities.QuizAttempt.filter({ 
        student_id: student.id, 
        quiz_id: quiz.id 
      });
      setAttempts(userAttempts);
      setCurrentAttemptNumber(userAttempts.length + 1);
    } catch (error) {
      console.error("Error reloading attempts:", error);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const canAttemptAgain = () => {
    if (!quiz.max_attempts || quiz.max_attempts === 0) return true;
    const completedAttemptsCount = attempts.filter(a => a.status === 'completed').length;
    return completedAttemptsCount < quiz.max_attempts;
  };

  const getProgressPercentage = () => {
    const answeredCount = Object.keys(answers).filter(key => {
      const question = quiz.questions[key];
      const answer = answers[key];
      
      if (question.question_type === 'multiple_choice') {
        return Array.isArray(answer) ? answer.length > 0 : answer !== null && answer !== undefined;
      }
      if (question.question_type === 'matrix') {
        return typeof answer === 'object' && answer !== null && Object.values(answer).some(val => val === true);
      }
      if (question.question_type === 'ranking') {
        return Array.isArray(answer) && answer.length === question.options.length;
      }
      return false;
    }).length;
    
    return Math.round((answeredCount / quiz.questions.length) * 100);
  };

  const isCurrentQuestionAnswered = () => {
    const question = quiz.questions[currentQuestionIndex];
    const answer = answers[currentQuestionIndex];

    if (question.question_type === 'multiple_choice') {
      return Array.isArray(answer) ? answer.length > 0 : answer !== null && answer !== undefined;
    }
    if (question.question_type === 'matrix') {
      return typeof answer === 'object' && answer !== null && Object.values(answer).some(val => val === true);
    }
    if (question.question_type === 'ranking') {
      return Array.isArray(answer) && answer.length === question.options.length;
    }
    return false;
  };

  const allQuestionsAnswered = () => {
    return quiz.questions.every((_, idx) => {
      const question = quiz.questions[idx];
      const answer = answers[idx];

      if (question.question_type === 'multiple_choice') {
        return Array.isArray(answer) ? answer.length > 0 : answer !== null && answer !== undefined;
      }
      if (question.question_type === 'matrix') {
        return typeof answer === 'object' && answer !== null && Object.values(answer).some(val => val === true);
      }
      if (question.question_type === 'ranking') {
        return Array.isArray(answer) && answer.length === question.options.length;
      }
      return false;
    });
  };

  const goToNextQuestion = () => {
    if (currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  if (!canTakeQuiz && !showResults) {
    return (
      <div className="p-8 text-center">
        <AlertTriangle className="w-16 h-16 text-amber-500 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-gray-900 mb-2">Quiz Locked</h3>
        <p className="text-gray-600 mb-4">Complete the following videos before taking this quiz:</p>
        <ul className="text-left max-w-md mx-auto space-y-2">
          {missingVideos.map(video => (
            <li key={video.id} className="flex items-center text-gray-700">
              <XCircle className="w-4 h-4 text-red-500 mr-2" />
              {video.title}
            </li>
          ))}
        </ul>
      </div>
    );
  }

  if (showResults) {
    const passed = quiz.passing_score ? score >= quiz.passing_score : true;
    const completedAttempts = attempts.filter(a => a.status === 'completed').length;
    const maxedOut = quiz.max_attempts && completedAttempts >= quiz.max_attempts;
    const shouldContactInstructor = maxedOut && !passed;
    
    return (
      <div className="p-8 bg-gray-50 min-h-screen">
        <div className="text-center mb-12">
          <div className={`w-24 h-24 rounded-full mx-auto mb-6 flex items-center justify-center ${
            passed ? 'bg-green-100' : 'bg-red-100'
          }`}>
            {passed ? (
              <CheckCircle className="w-12 h-12 text-green-600" />
            ) : (
              <XCircle className="w-12 h-12 text-red-600" />
            )}
          </div>
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            {passed ? 'Congratulations!' : 'Keep Trying!'}
          </h2>
          <p className="text-2xl text-gray-700 mb-2">
            Your Score: <span className={`font-bold ${passed ? 'text-blue-600' : 'text-red-600'}`}>{score}%</span>
          </p>
          {quiz.passing_score && (
            <p className="text-lg text-gray-500">
              Passing Score: {quiz.passing_score}%
            </p>
          )}
        </div>

        {shouldContactInstructor && (
          <div className="max-w-4xl mx-auto mb-8">
            <div className="bg-amber-50 border-2 border-amber-300 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <AlertTriangle className="w-8 h-8 text-amber-600 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-amber-900 mb-2">Need Help?</h3>
                  <p className="text-amber-800 mb-4">
                    You've reached the maximum number of attempts ({quiz.max_attempts}) without passing. 
                    We recommend contacting your instructor for additional support and guidance.
                  </p>
                  <Link to={createPageUrl("Messages")}>
                    <Button className="bg-amber-600 hover:bg-amber-700 text-white">
                      <MessageSquare className="w-4 h-4 mr-2" />
                      Contact Instructor
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        )}

        {!passed && canAttemptAgain() && !shouldContactInstructor && (
          <div className="max-w-4xl mx-auto mb-8">
            <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6">
              <div className="flex items-start gap-4">
                <AlertTriangle className="w-8 h-8 text-blue-600 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-blue-900 mb-2">Don't Give Up!</h3>
                  <p className="text-blue-800 mb-4">
                    You didn't pass this time, but you can try again! Review your course materials and attempt the quiz once more.
                  </p>
                  <p className="text-sm text-blue-700">
                    Attempts remaining: {quiz.max_attempts ? quiz.max_attempts - completedAttempts : 'Unlimited'}
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {passed && (
          <div className="max-w-4xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Review Your Answers</h3>
            <div className="space-y-6">
              {quiz.questions.map((question, qIndex) => {
                const userAnswer = answers[qIndex];
                let isCorrect = false;
                
                if (question.question_type === 'multiple_choice') {
                  const correctAnswers = Array.isArray(question.correct_answer) ? question.correct_answer : [];
                  const userAnswers = Array.isArray(userAnswer) ? userAnswer : (userAnswer !== null && userAnswer !== undefined ? [userAnswer] : []);
                  isCorrect = correctAnswers.length === userAnswers.length && correctAnswers.every(ans => userAnswers.includes(ans));
                }
                
                return (
                  <div key={qIndex} className="bg-white rounded-xl p-6 shadow-md border-2 border-gray-100">
                    <div className="flex items-start gap-3 mb-4">
                      {isCorrect ? (
                        <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-600 flex-shrink-0 mt-1" />
                      )}
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900 text-lg mb-4">
                          Question {qIndex + 1}: {question.question}
                        </h4>
                        
                        {question.question_type === 'multiple_choice' && (
                          <div className="space-y-3">
                            {question.options.map((option, oIndex) => {
                              const isUserAnswer = Array.isArray(userAnswer) ? userAnswer.includes(oIndex) : userAnswer === oIndex;
                              const isCorrectAnswer = question.correct_answer.includes(oIndex);
                              
                              return (
                                <div
                                  key={oIndex}
                                  className={`p-4 rounded-lg border-2 transition-all ${
                                    isCorrectAnswer && isUserAnswer
                                      ? 'border-green-500 bg-green-50'
                                      : isCorrectAnswer
                                      ? 'border-green-500 bg-green-50'
                                      : isUserAnswer
                                      ? 'border-red-500 bg-red-50'
                                      : 'border-gray-200 bg-white'
                                  }`}
                                >
                                  <div className="flex items-center gap-3">
                                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center flex-shrink-0 ${
                                      isUserAnswer
                                        ? isCorrectAnswer
                                          ? 'border-green-600 bg-green-600'
                                          : 'border-red-600 bg-red-600'
                                        : isCorrectAnswer
                                        ? 'border-green-600 bg-green-600'
                                        : 'border-gray-300'
                                    }`}>
                                      {(isUserAnswer || isCorrectAnswer) && (
                                        <div className="w-3 h-3 bg-white rounded-full" />
                                      )}
                                    </div>
                                    <span className="flex-1 text-gray-800">{option}</span>
                                    {isCorrectAnswer && (
                                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                                    )}
                                    {!isCorrectAnswer && isUserAnswer && (
                                      <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        )}
                        
                        {question.explanation && (
                          <div className="mt-6 p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                            <p className="font-semibold text-blue-900 mb-2 flex items-center gap-2">
                              <AlertTriangle className="w-4 h-4" />
                              Rationale:
                            </p>
                            <p className="text-blue-800 text-sm leading-relaxed">{question.explanation}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {canAttemptAgain() && (
          <div className="mt-8 text-center">
            <Button 
              onClick={handleTryAgain}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-lg font-semibold text-lg"
            >
              Try Again
            </Button>
            {quiz.max_attempts && (
              <p className="text-sm text-gray-600 mt-3">
                Attempts remaining: {quiz.max_attempts - completedAttempts}
              </p>
            )}
          </div>
        )}
      </div>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];

  return (
    <div className="flex flex-col h-screen">
      <div className="bg-white border-b-2 border-gray-200 p-6 flex-shrink-0">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">{quiz.title}</h2>
            <p className="text-sm text-gray-600 mt-1">
              Question {currentQuestionIndex + 1} of {quiz.questions.length}
            </p>
          </div>
          {timeRemaining !== null && (
            <div className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
              timeRemaining < 300 ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
            }`}>
              <Clock className="w-5 h-5" />
              <span className="font-bold">{formatTime(timeRemaining)}</span>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-8 pb-32">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-xl p-6 shadow-md border-2 border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900 mb-6">
              {currentQuestion.question}
            </h3>

            {currentQuestion.question_type === 'multiple_choice' && (
              <div className="space-y-3">
                {currentQuestion.required_answers_count > 1 ? (
                  <>
                    <p className="text-sm text-gray-600 mb-3 italic">
                      Select {currentQuestion.required_answers_count} answers
                    </p>
                    {currentQuestion.options.map((option, oIndex) => (
                      <div key={oIndex} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors border border-gray-200">
                        <Checkbox
                          id={`q${currentQuestionIndex}-o${oIndex}`}
                          checked={Array.isArray(answers[currentQuestionIndex]) && answers[currentQuestionIndex].includes(oIndex)}
                          onCheckedChange={(checked) => {
                            const currentAnswers = Array.isArray(answers[currentQuestionIndex]) ? [...answers[currentQuestionIndex]] : [];
                            if (checked) {
                              if (currentAnswers.length < currentQuestion.required_answers_count) {
                                handleAnswerChange(currentQuestionIndex, [...currentAnswers, oIndex]);
                              }
                            } else {
                              handleAnswerChange(currentQuestionIndex, currentAnswers.filter(a => a !== oIndex));
                            }
                          }}
                        />
                        <Label htmlFor={`q${currentQuestionIndex}-o${oIndex}`} className="flex-1 cursor-pointer text-base">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </>
                ) : (
                  <RadioGroup
                    value={answers[currentQuestionIndex]?.toString() || ''}
                    onValueChange={(value) => handleAnswerChange(currentQuestionIndex, parseInt(value))}
                  >
                    {currentQuestion.options.map((option, oIndex) => (
                      <div key={oIndex} className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors border border-gray-200">
                        <RadioGroupItem value={oIndex.toString()} id={`q${currentQuestionIndex}-o${oIndex}`} />
                        <Label htmlFor={`q${currentQuestionIndex}-o${oIndex}`} className="flex-1 cursor-pointer text-base">
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
              </div>
            )}

            {currentQuestion.question_type === 'matrix' && (
              <div className="overflow-x-auto">
                <table className="min-w-full border-collapse">
                  <thead>
                    <tr>
                      <th className="border-2 border-gray-300 p-3 bg-gray-50"></th>
                      {currentQuestion.matrix_columns?.map((col, cIndex) => (
                        <th key={cIndex} className="border-2 border-gray-300 p-3 text-center bg-gray-50 font-semibold">
                          {col}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {currentQuestion.matrix_rows?.map((row, rIndex) => (
                      <tr key={rIndex}>
                        <td className="border-2 border-gray-300 p-3 font-semibold bg-gray-50">{row}</td>
                        {currentQuestion.matrix_columns?.map((col, cIndex) => (
                          <td key={cIndex} className="border-2 border-gray-300 p-3 text-center">
                            <Checkbox
                              checked={answers[currentQuestionIndex]?.[`${rIndex}-${cIndex}`] || false}
                              onCheckedChange={(checked) => handleMatrixChange(currentQuestionIndex, rIndex, cIndex, checked)}
                              className="mx-auto"
                            />
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {currentQuestion.question_type === 'ranking' && (
              <div>
                <p className="text-sm text-gray-600 mb-3 italic">
                  Drag to reorder from most important to least important
                </p>
                <DragDropContext onDragEnd={(result) => handleRankingReorder(currentQuestionIndex, result)}>
                  <Droppable droppableId={`ranking-${currentQuestionIndex}`}>
                    {(provided) => (
                      <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-2">
                        {(rankingOrders[currentQuestionIndex] || currentQuestion.options.map((_, idx) => idx)).map((optionIndex, position) => (
                          <Draggable
                            key={optionIndex}
                            draggableId={`q${currentQuestionIndex}-o${optionIndex}`}
                            index={position}
                          >
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                                className={`flex items-center gap-3 p-4 rounded-lg border-2 ${
                                  snapshot.isDragging
                                    ? 'border-blue-500 bg-blue-50 shadow-lg'
                                    : 'border-gray-300 bg-white hover:border-gray-400'
                                } transition-all`}
                              >
                                <GripVertical className="w-5 h-5 text-gray-400 flex-shrink-0" />
                                <span className="flex-1 text-base">{currentQuestion.options[optionIndex]}</span>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                      </div>
                    )}
                  </Droppable>
                </DragDropContext>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="fixed bottom-0 left-0 right-0 bg-white border-t-2 border-gray-200 p-6 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex justify-between items-center mb-3">
            <span className="text-sm font-medium text-gray-700">
              Progress: {Object.keys(answers).length} / {quiz.questions.length} questions answered
            </span>
            <span className="text-sm font-bold text-blue-600">
              {getProgressPercentage()}%
            </span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
            <div
              className="bg-gradient-to-r from-blue-500 to-teal-500 h-3 rounded-full transition-all duration-300"
              style={{ width: `${getProgressPercentage()}%` }}
            ></div>
          </div>
          <div className="flex justify-between items-center">
            <Button
              onClick={goToPreviousQuestion}
              disabled={currentQuestionIndex === 0}
              variant="outline"
              className="flex items-center gap-2"
            >
              <ChevronLeft className="w-4 h-4" />
              Previous
            </Button>

            {currentQuestionIndex < quiz.questions.length - 1 ? (
              <Button
                onClick={goToNextQuestion}
                className="bg-gradient-to-r from-blue-600 to-teal-600 hover:from-blue-700 hover:to-teal-700 flex items-center gap-2"
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button
                onClick={handleSubmit}
                disabled={isSubmitting || !allQuestionsAnswered()}
                className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 px-8 py-3 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Submitting...' : 'Submit Quiz'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
