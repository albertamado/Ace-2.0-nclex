import React, { useState, useEffect } from 'react';
import { Reaction } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { ThumbsUp, MessageCircle } from 'lucide-react';
import { format } from 'date-fns';
import CommentsSection from './CommentsSection';

export default function AnnouncementItem({ announcement, author, currentUser, users }) {
  const [reactions, setReactions] = useState([]);
  const [hasReacted, setHasReacted] = useState(false);
  const [showComments, setShowComments] = useState(false);

  useEffect(() => {
    loadReactions();
  }, [announcement.id]);

  const loadReactions = async () => {
    try {
      const announcementReactions = await Reaction.filter({ 
        content_id: announcement.id, 
        content_type: 'announcement' 
      });
      setReactions(announcementReactions);
      setHasReacted(announcementReactions.some(r => r.user_id === currentUser.id));
    } catch (error) {
      console.error("Error loading reactions:", error);
    }
  };

  const handleReaction = async () => {
    try {
      if (hasReacted) {
        const userReaction = reactions.find(r => r.user_id === currentUser.id);
        if (userReaction) {
          await Reaction.delete(userReaction.id);
        }
      } else {
        await Reaction.create({
          content_id: announcement.id,
          content_type: 'announcement',
          user_id: currentUser.id,
          reaction_type: 'like'
        });
      }
      await loadReactions();
    } catch (error) {
      console.error("Error handling reaction:", error);
    }
  };

  // Safely get author info with fallbacks
  const authorName = author?.full_name || 'Unknown User';
  const authorEmail = author?.email || 'N/A';
  const authorInitial = authorName?.[0]?.toUpperCase() || 'U';
  const authorPhoto = author?.profile_photo_url;

  return (
    <div className="border-b border-gray-100 pb-6 last:border-b-0">
      <div className="flex items-start space-x-4">
        {authorPhoto ? (
          <img src={authorPhoto} alt={authorName} className="w-10 h-10 rounded-full object-cover" />
        ) : (
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
            <span className="text-sm font-medium text-blue-600">{authorInitial}</span>
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex items-baseline justify-between mb-2">
            <div>
              <h4 className="font-semibold text-gray-900">{authorName}</h4>
              <p className="text-sm text-gray-500">{authorEmail}</p>
            </div>
            <span className="text-sm text-gray-500">
              {format(new Date(announcement.created_date), 'MMM d, yyyy h:mm a')}
            </span>
          </div>
          <p className="text-gray-700 whitespace-pre-wrap break-words">{announcement.content}</p>
          
          <div className="flex items-center space-x-4 mt-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleReaction}
              className={hasReacted ? 'text-blue-600' : 'text-gray-500'}
            >
              <ThumbsUp className={`w-4 h-4 mr-1 ${hasReacted ? 'fill-current' : ''}`} />
              {reactions.length > 0 && <span>{reactions.length}</span>}
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowComments(!showComments)}
              className="text-gray-500"
            >
              <MessageCircle className="w-4 h-4 mr-1" />
              Comments
            </Button>
          </div>

          {showComments && (
            <div className="mt-4">
              <CommentsSection
                contentId={announcement.id}
                contentType="announcement"
                courseId={announcement.course_id}
                currentUser={currentUser}
                users={users}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}