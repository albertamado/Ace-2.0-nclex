import React, { useState, useCallback } from 'react';
import { Comment } from '@/api/entities';
import { Reaction } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ThumbsUp, MessageCircle, Send } from 'lucide-react';
import { format } from 'date-fns';
import { getUserRole } from '../utils/getUserRole';

export default function CommentItem({ comment, author, currentUser, allComments, users, onReply, courseId, contentId, contentType }) {
  const [showReplyForm, setShowReplyForm] = useState(false);
  const [replyContent, setReplyContent] = useState('');
  const [isPosting, setIsPosting] = useState(false);
  const [reactions, setReactions] = useState([]);
  const [hasReacted, setHasReacted] = useState(false);

  const loadReactions = useCallback(async () => {
    try {
      const commentReactions = await Reaction.filter({ content_id: comment.id, content_type: 'comment' });
      setReactions(commentReactions);
      setHasReacted(commentReactions.some(r => r.user_id === currentUser.id));
    } catch (error) {
      console.error("Error loading reactions:", error);
    }
  }, [comment.id, currentUser.id]);

  React.useEffect(() => {
    loadReactions();
  }, [loadReactions]);

  const handleReact = async () => {
    try {
      if (hasReacted) {
        const userReaction = reactions.find(r => r.user_id === currentUser.id);
        if (userReaction) {
          await Reaction.delete(userReaction.id);
        }
      } else {
        await Reaction.create({
          content_id: comment.id,
          content_type: 'comment',
          user_id: currentUser.id,
          reaction_type: 'like'
        });
      }
      await loadReactions();
    } catch (error) {
      console.error("Error reacting:", error);
    }
  };

  const handlePostReply = async () => {
    if (!replyContent.trim()) return;
    setIsPosting(true);
    try {
      await Comment.create({
        course_id: courseId,
        content_id: contentId,
        content_type: contentType,
        user_id: currentUser.id,
        content: replyContent,
        parent_comment_id: comment.id
      });
      setReplyContent('');
      setShowReplyForm(false);
      if (onReply) onReply();
    } catch (error) {
      console.error("Error posting reply:", error);
    }
    setIsPosting(false);
  };

  const replies = allComments.filter(c => c.parent_comment_id === comment.id);

  const getRoleBadge = (user) => {
    if (!user) return null;
    const role = getUserRole(user);
    
    const badges = {
      'admin': { text: 'Admin', color: 'bg-purple-100 text-purple-700' },
      'teacher': { text: 'Instructor', color: 'bg-blue-100 text-blue-700' },
      'student': null
    };
    
    const badge = badges[role];
    if (!badge) return null;
    
    return (
      <span className={`text-xs px-2 py-0.5 rounded-full ${badge.color}`}>
        {badge.text}
      </span>
    );
  };

  return (
    <div className="space-y-4">
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0">
          {author?.profile_photo_url ? (
            <img src={author.profile_photo_url} alt={author.full_name} className="w-10 h-10 rounded-full object-cover" />
          ) : (
            <div className="w-10 h-10 bg-gray-200 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-gray-600">
                {author?.full_name?.[0]?.toUpperCase() || 'U'}
              </span>
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center space-x-2 mb-2">
              <span className="font-medium text-gray-900">{author?.full_name || 'Unknown User'}</span>
              {getRoleBadge(author)}
              <span className="text-xs text-gray-500">
                {format(new Date(comment.created_date), 'MMM d, yyyy h:mm a')}
              </span>
            </div>
            <p className="text-gray-700 text-sm whitespace-pre-wrap">{comment.content}</p>
          </div>
          
          <div className="flex items-center space-x-4 mt-2">
            <button
              onClick={handleReact}
              className={`flex items-center space-x-1 text-sm ${hasReacted ? 'text-blue-600' : 'text-gray-500'} hover:text-blue-600`}
            >
              <ThumbsUp className="w-4 h-4" />
              <span>{reactions.length > 0 && reactions.length}</span>
            </button>
            <button
              onClick={() => setShowReplyForm(!showReplyForm)}
              className="flex items-center space-x-1 text-sm text-gray-500 hover:text-blue-600"
            >
              <MessageCircle className="w-4 h-4" />
              <span>Reply</span>
            </button>
          </div>

          {showReplyForm && (
            <div className="mt-3 flex items-start space-x-2">
              <Textarea
                placeholder="Write a reply..."
                value={replyContent}
                onChange={(e) => setReplyContent(e.target.value)}
                className="flex-1"
                rows={2}
              />
              <Button onClick={handlePostReply} disabled={isPosting} size="sm">
                <Send className="w-4 h-4" />
              </Button>
            </div>
          )}

          {replies.length > 0 && (
            <div className="mt-4 space-y-4 ml-6 border-l-2 border-gray-200 pl-4">
              {replies.map((reply) => (
                <CommentItem
                  key={reply.id}
                  comment={reply}
                  author={users[reply.user_id]}
                  currentUser={currentUser}
                  allComments={allComments}
                  users={users}
                  onReply={onReply}
                  courseId={courseId}
                  contentId={contentId}
                  contentType={contentType}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}